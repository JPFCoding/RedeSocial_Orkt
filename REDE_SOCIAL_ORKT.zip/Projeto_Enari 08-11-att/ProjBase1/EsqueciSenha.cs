﻿using System;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

namespace ProjBase1
{
    public partial class EsqueciSenha : Form
    {
        private string verificationCode;
        private string recoveryEmail;
        private static Random random = new Random();

        public EsqueciSenha()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.ShowDialog();
            this.Close();
        }

        private void MandarCodigo_Click(object sender, EventArgs e)
        {
            recoveryEmail = textEmail.Text; // Captura o e-mail fornecido

            // Verifica se o e-mail está registrado
            if (IsEmailRegistered(recoveryEmail))
            {
                // Gera o código de verificação e envia para o e-mail
                verificationCode = GenerateVerificationCode();
                SendVerificationEmail(recoveryEmail, verificationCode);

                MessageBox.Show("Código de verificação enviado para o e-mail registrado.");
            }
            else
            {
                MessageBox.Show("E-mail não registrado.");
            }
        }

        private bool IsEmailRegistered(string email)
        {
            // Percorre a lista de perfis para verificar se o e-mail está registrado
            var atual = Form2.cabeca;
            while (atual != null)
            {
                if (atual.Dados[2] == email) // Supondo que Dados[2] é o campo de e-mail
                {
                    return true;
                }
                atual = atual.Proximo;
            }
            return false;
        }

        private string GenerateVerificationCode()
        {
            return random.Next(100000, 999999).ToString(); // Gera um código de 6 dígitos
        }

        private void SendVerificationEmail(string email, string code)
        {
            string fromAddress = "ruanzinho.antico@hotmail.com"; // Seu e-mail do Outlook.com ou Hotmail
            string fromPassword = ""; // A senha comum da sua conta do Outlook

            try
            {
                using (MailMessage message = new MailMessage(fromAddress, email))
                {
                    message.Subject = "Código de Recuperação de Senha";
                    message.Body = $"Seu código de verificação é: {code}";

                    using (SmtpClient smtp = new SmtpClient("smtp-mail.outlook.com", 587))
                    {
                        smtp.EnableSsl = true; // Ativa conexão SSL segura
                        smtp.Credentials = new NetworkCredential(fromAddress, fromPassword);
                        smtp.Send(message);
                    }
                }
                MessageBox.Show("Código enviado com sucesso!");
            }
            catch (SmtpException smtpEx)
            {
                MessageBox.Show($"Erro ao enviar e-mail (SMTP): {smtpEx.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro inesperado: {ex.Message}");
            }
        }




        private void verificar_Click(object sender, EventArgs e)
        {
            string codigoInserido = richTextCodigo.Text;

            if (codigoInserido == verificationCode)
            {
                MessageBox.Show("Código verificado com sucesso. Insira uma nova senha.");
                novasenha.Visible = true; // Exibe o campo para nova senha
                Confirmar.Visible = true; // Exibe o botão de confirmar
            }
            else
            {
                MessageBox.Show("Código incorreto. Tente novamente.");
            }
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            string novaSenha = novasenha.Text;

            if (string.IsNullOrWhiteSpace(novaSenha))
            {
                MessageBox.Show("Por favor, insira uma nova senha.");
                return;
            }

            // Atualiza a senha no perfil do usuário
            RedefinirSenha(recoveryEmail, novaSenha);
            MessageBox.Show("Senha redefinida com sucesso!");

            // Limpa o código e esconde os campos de redefinição
            verificationCode = null;
            novasenha.Visible = false;
            Confirmar.Visible = false;
        }

        private void RedefinirSenha(string email, string novaSenha)
        {
            var atual = Form2.cabeca;
            while (atual != null)
            {
                if (atual.Dados[2] == email)
                {
                    atual.Dados[1] = novaSenha; // Supondo que Dados[1] é o campo de senha
                    break;
                }
                atual = atual.Proximo;
            }
        }

        private void textEmail_TextChanged(object sender, EventArgs e)
        {
        }

        private void richTextCodigo_TextChanged(object sender, EventArgs e)
        {
        }

        private void novasenha_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
