﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ProjBase1
{
    public partial class MostrarAmigo : Form
    {
        // Supondo que a lista de amigos esteja disponível
        private List<string> amigos;

        public MostrarAmigo(List<string> listaAmigos)
        {
            InitializeComponent();
            amigos = listaAmigos;
            ExibirAmigos(); // Chama o método que exibe os amigos
        }

        private void ExibirAmigos()
        {
            flowLayoutPanel1.Controls.Clear(); // Limpa o painel antes de adicionar novos controles

            foreach (var amigo in amigos)
            {
                // Cria um label para exibir o nome do amigo
                Label labelAmigo = new Label();
                labelAmigo.Text = amigo;
                labelAmigo.AutoSize = true;
                labelAmigo.Margin = new Padding(5);
                labelAmigo.Font = new Font("Arial", 10, FontStyle.Bold);

                // Adiciona o label ao FlowLayoutPanel
                flowLayoutPanel1.Controls.Add(labelAmigo);
            }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            // Esse método pode ser deixado vazio, pois não é necessário para exibir os amigos
        }
    }
}
