﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ProjBase1.Community;
using static ProjBase1.Form4;

namespace ProjBase1
{
    public partial class FormComunidade : Form
    {
        private Comunidade comunidade;

        public FormComunidade(Comunidade comunidade)
        {
            InitializeComponent();
            this.comunidade = comunidade;
            labelNome.Text = comunidade.Nome;
            labelDescricao.Text = comunidade.Descricao;
            pictureBoxFoto.Image = comunidade.Foto;
            AtualizarPosts();
            this.StartPosition = FormStartPosition.CenterScreen;


            if (comunidade.Dono == DadosUsuario.UsuarioLogado.Nome)
            {
                apagarComunidade.Visible = true;
                sairComunidade.Visible = false;
            }
            else
            {
                apagarComunidade.Visible = false;
                sairComunidade.Visible = true;
            }
                panelPostar.Visible = comunidade.Dono == DadosUsuario.UsuarioLogado.Nome;
        }

        private void AtualizarPosts()
        {
            listBoxPosts.Items.Clear();
            foreach (var post in comunidade.Posts)
            {
                listBoxPosts.Items.Add(post);
            }
        }

        private void btnPostar_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBoxPost.Text))
            {
                // Adiciona o post ao final da lista, com o nome do usuário logado.
                comunidade.Posts.Add($"{DadosUsuario.UsuarioLogado.Nome}: {textBoxPost.Text}");
                textBoxPost.Clear();
                AtualizarPosts();
            }
        }

        private void FormComunidade_Load(object sender, EventArgs e)
        {
            
        }

        private void apagarComunidade_Click(object sender, EventArgs e)
        {
            // Confirmação de exclusão
            var result = MessageBox.Show("Tem certeza de que deseja apagar esta comunidade?", "Apagar Comunidade", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                // Remove a comunidade da lista global
                Community.ComunidadeRepository.TodasComunidades.Remove(comunidade);
                MessageBox.Show("Comunidade apagada com sucesso.");
                Community community = new Community();
                community.Show();
                this.Close();
                Refresh(); 
            }
        }


        private void sairComunidade_Click(object sender, EventArgs e)
        {
            if (comunidade.Membros.Contains(DadosUsuario.UsuarioLogado.Nome))
            {
                comunidade.Membros.Remove(DadosUsuario.UsuarioLogado.Nome);
                MessageBox.Show("Você saiu da comunidade.");
                Community community = new Community();
                community.Show();
                this.Close();
                Refresh();
            }
            else
            {
                MessageBox.Show("Você não faz parte desta comunidade.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxFoto_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
