﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjBase1
{
    public partial class ConfigForm : Form
    {
        public ConfigForm()
        {
            InitializeComponent();
        }

        private void ConfigForm_Load(object sender, EventArgs e)
        {

        }

        private void chkTemaEscuro_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTemaEscuro.Checked)
            {
                // Ativar modo escuro
                this.BackColor = Color.FromArgb(45, 45, 48); // Cor de fundo escura
                this.ForeColor = Color.White; // Cor do texto
                AlterarCoresDosControles(this, Color.FromArgb(28, 28, 30), Color.White);
            }
            else
            {
                // Ativar modo claro
                this.BackColor = Color.White; // Cor de fundo clara
                this.ForeColor = Color.Black; // Cor do texto
                AlterarCoresDosControles(this, Color.White, Color.Black);

            }
        }

        private void AlterarCoresDosControles(Control parent, Color backgroundColor, Color textColor)
        {
            foreach (Control control in parent.Controls)
            {
                if (control is Panel || control is GroupBox)
                {
                    // Recursivamente altera os controles dentro de Painéis e GroupBoxes
                    AlterarCoresDosControles(control, backgroundColor, textColor);
                }
                else if (control is Button || control is Label || control is CheckBox)
                {
                    // Altera a cor de fundo e a cor do texto dos botões, labels e checkboxes
                    control.BackColor = backgroundColor;
                    control.ForeColor = textColor;
                }
            }
        }
    }
}
