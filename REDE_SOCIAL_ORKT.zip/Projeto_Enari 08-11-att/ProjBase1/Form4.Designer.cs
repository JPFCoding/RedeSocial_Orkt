﻿namespace ProjBase1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.new_post = new System.Windows.Forms.Button();
            this.PostText = new System.Windows.Forms.Panel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.nomeUsuario = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanelAmigos = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.btHome = new System.Windows.Forms.Button();
            this.btMenu = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btComunidade = new System.Windows.Forms.Button();
            this.btSettings = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.btAmigos = new System.Windows.Forms.Button();
            this.btProfile = new System.Windows.Forms.Button();
            this.textBoxNomeAmigo = new System.Windows.Forms.RichTextBox();
            this.btnAdicionarAmigo = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanelSolicitacoes = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // new_post
            // 
            this.new_post.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.new_post.Cursor = System.Windows.Forms.Cursors.Hand;
            this.new_post.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.new_post.FlatAppearance.BorderSize = 3;
            this.new_post.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.new_post.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.new_post.ForeColor = System.Drawing.Color.White;
            this.new_post.Location = new System.Drawing.Point(269, 484);
            this.new_post.Name = "new_post";
            this.new_post.Size = new System.Drawing.Size(198, 38);
            this.new_post.TabIndex = 4;
            this.new_post.Text = "Adicionar Publicação";
            this.new_post.UseVisualStyleBackColor = false;
            this.new_post.Click += new System.EventHandler(this.new_post_Click);
            // 
            // PostText
            // 
            this.PostText.AutoScroll = true;
            this.PostText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.PostText.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PostText.Location = new System.Drawing.Point(501, 149);
            this.PostText.Name = "PostText";
            this.PostText.Size = new System.Drawing.Size(526, 539);
            this.PostText.TabIndex = 5;
            this.PostText.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // nomeUsuario
            // 
            this.nomeUsuario.AutoSize = true;
            this.nomeUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.nomeUsuario.ForeColor = System.Drawing.Color.White;
            this.nomeUsuario.Location = new System.Drawing.Point(270, 355);
            this.nomeUsuario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nomeUsuario.Name = "nomeUsuario";
            this.nomeUsuario.Size = new System.Drawing.Size(79, 29);
            this.nomeUsuario.TabIndex = 8;
            this.nomeUsuario.Text = "Nome";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Location = new System.Drawing.Point(-6, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1306, 33);
            this.panel1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(40, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 29);
            this.label1.TabIndex = 24;
            this.label1.Text = "Perfil";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ProjBase1.Properties.Resources.logoSquirrel24;
            this.pictureBox4.Location = new System.Drawing.Point(12, 5);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(24, 24);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 23;
            this.pictureBox4.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Location = new System.Drawing.Point(1066, 32);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(223, 31);
            this.panel3.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(43, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Lista de Amigos";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ProjBase1.Properties.Resources.icons8_friends_28;
            this.pictureBox3.Location = new System.Drawing.Point(10, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 31);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // flowLayoutPanelAmigos
            // 
            this.flowLayoutPanelAmigos.AutoScroll = true;
            this.flowLayoutPanelAmigos.Location = new System.Drawing.Point(1067, 64);
            this.flowLayoutPanelAmigos.Margin = new System.Windows.Forms.Padding(2);
            this.flowLayoutPanelAmigos.Name = "flowLayoutPanelAmigos";
            this.flowLayoutPanelAmigos.Size = new System.Drawing.Size(212, 431);
            this.flowLayoutPanelAmigos.TabIndex = 21;
            this.flowLayoutPanelAmigos.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanelAmigos_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.btHome);
            this.panel2.Controls.Add(this.btMenu);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btComunidade);
            this.panel2.Controls.Add(this.btSettings);
            this.panel2.Controls.Add(this.pictureBox5);
            this.panel2.Controls.Add(this.btAmigos);
            this.panel2.Controls.Add(this.btProfile);
            this.panel2.Location = new System.Drawing.Point(0, 33);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(212, 688);
            this.panel2.TabIndex = 24;
            // 
            // textBox1
            // 
            this.textBox1.AutoSize = true;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(35, 63);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(0, 20);
            this.textBox1.TabIndex = 20;
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = global::ProjBase1.Properties.Resources.icons8_logout_28;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 629);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(212, 53);
            this.button2.TabIndex = 12;
            this.button2.Text = "   Desconectar-se";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btHome
            // 
            this.btHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btHome.FlatAppearance.BorderSize = 0;
            this.btHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHome.ForeColor = System.Drawing.Color.White;
            this.btHome.Image = global::ProjBase1.Properties.Resources.home_28;
            this.btHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btHome.Location = new System.Drawing.Point(0, 215);
            this.btHome.Name = "btHome";
            this.btHome.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btHome.Size = new System.Drawing.Size(212, 53);
            this.btHome.TabIndex = 9;
            this.btHome.Text = " Página Inicial";
            this.btHome.UseVisualStyleBackColor = true;
            this.btHome.Click += new System.EventHandler(this.btHome_Click);
            // 
            // btMenu
            // 
            this.btMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btMenu.FlatAppearance.BorderSize = 0;
            this.btMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btMenu.ForeColor = System.Drawing.Color.White;
            this.btMenu.Image = global::ProjBase1.Properties.Resources.menu_28;
            this.btMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btMenu.Location = new System.Drawing.Point(0, 4);
            this.btMenu.Name = "btMenu";
            this.btMenu.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btMenu.Size = new System.Drawing.Size(212, 53);
            this.btMenu.TabIndex = 0;
            this.btMenu.Text = "Menu";
            this.btMenu.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = global::ProjBase1.Properties.Resources.icons8_game_28;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 431);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(212, 53);
            this.button1.TabIndex = 11;
            this.button1.Text = "      Jogos";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btComunidade
            // 
            this.btComunidade.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btComunidade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.btComunidade.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btComunidade.FlatAppearance.BorderSize = 0;
            this.btComunidade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btComunidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btComunidade.ForeColor = System.Drawing.Color.White;
            this.btComunidade.Image = global::ProjBase1.Properties.Resources.icons8_community_28;
            this.btComunidade.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btComunidade.Location = new System.Drawing.Point(0, 323);
            this.btComunidade.Name = "btComunidade";
            this.btComunidade.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btComunidade.Size = new System.Drawing.Size(212, 53);
            this.btComunidade.TabIndex = 0;
            this.btComunidade.Text = "   Comunidade";
            this.btComunidade.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btComunidade.UseVisualStyleBackColor = false;
            this.btComunidade.Click += new System.EventHandler(this.btComunidade_Click);
            // 
            // btSettings
            // 
            this.btSettings.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.btSettings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btSettings.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btSettings.FlatAppearance.BorderSize = 0;
            this.btSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSettings.ForeColor = System.Drawing.Color.White;
            this.btSettings.Image = global::ProjBase1.Properties.Resources.icons8_settings_28;
            this.btSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btSettings.Location = new System.Drawing.Point(0, 485);
            this.btSettings.Name = "btSettings";
            this.btSettings.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btSettings.Size = new System.Drawing.Size(212, 53);
            this.btSettings.TabIndex = 3;
            this.btSettings.Text = "   Configurações";
            this.btSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btSettings.UseVisualStyleBackColor = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox5.Location = new System.Drawing.Point(13, 63);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(16, 20);
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // btAmigos
            // 
            this.btAmigos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btAmigos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.btAmigos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btAmigos.FlatAppearance.BorderSize = 0;
            this.btAmigos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAmigos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAmigos.ForeColor = System.Drawing.Color.White;
            this.btAmigos.Image = global::ProjBase1.Properties.Resources.icons8_add_user_28;
            this.btAmigos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btAmigos.Location = new System.Drawing.Point(0, 377);
            this.btAmigos.Name = "btAmigos";
            this.btAmigos.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btAmigos.Size = new System.Drawing.Size(212, 53);
            this.btAmigos.TabIndex = 1;
            this.btAmigos.Text = "      Amigos";
            this.btAmigos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btAmigos.UseVisualStyleBackColor = false;
            this.btAmigos.Click += new System.EventHandler(this.btAmigos_Click);
            // 
            // btProfile
            // 
            this.btProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.btProfile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btProfile.FlatAppearance.BorderSize = 0;
            this.btProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btProfile.ForeColor = System.Drawing.Color.White;
            this.btProfile.Image = global::ProjBase1.Properties.Resources.icons8_user_28;
            this.btProfile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btProfile.Location = new System.Drawing.Point(0, 269);
            this.btProfile.Name = "btProfile";
            this.btProfile.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btProfile.Size = new System.Drawing.Size(212, 53);
            this.btProfile.TabIndex = 4;
            this.btProfile.Text = "        Perfil";
            this.btProfile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btProfile.UseVisualStyleBackColor = false;
            this.btProfile.Click += new System.EventHandler(this.btProfile_Click);
            // 
            // textBoxNomeAmigo
            // 
            this.textBoxNomeAmigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNomeAmigo.Location = new System.Drawing.Point(20, 10);
            this.textBoxNomeAmigo.Name = "textBoxNomeAmigo";
            this.textBoxNomeAmigo.Size = new System.Drawing.Size(269, 26);
            this.textBoxNomeAmigo.TabIndex = 26;
            this.textBoxNomeAmigo.Text = "";
            // 
            // btnAdicionarAmigo
            // 
            this.btnAdicionarAmigo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAdicionarAmigo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionarAmigo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAdicionarAmigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnAdicionarAmigo.ForeColor = System.Drawing.Color.White;
            this.btnAdicionarAmigo.Location = new System.Drawing.Point(302, 9);
            this.btnAdicionarAmigo.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdicionarAmigo.Name = "btnAdicionarAmigo";
            this.btnAdicionarAmigo.Size = new System.Drawing.Size(163, 29);
            this.btnAdicionarAmigo.TabIndex = 25;
            this.btnAdicionarAmigo.Text = "Adicionar Amigos";
            this.btnAdicionarAmigo.UseVisualStyleBackColor = false;
            this.btnAdicionarAmigo.Click += new System.EventHandler(this.btnAdicionarAmigo_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.panel4.Controls.Add(this.textBoxNomeAmigo);
            this.panel4.Controls.Add(this.btnAdicionarAmigo);
            this.panel4.Location = new System.Drawing.Point(392, 60);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(482, 47);
            this.panel4.TabIndex = 27;
            this.panel4.Visible = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.pictureBox2);
            this.panel5.Location = new System.Drawing.Point(1066, 496);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(260, 31);
            this.panel5.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(43, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Notificações";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProjBase1.Properties.Resources.icons8_notification_28;
            this.pictureBox2.Location = new System.Drawing.Point(10, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // flowLayoutPanelSolicitacoes
            // 
            this.flowLayoutPanelSolicitacoes.AutoScroll = true;
            this.flowLayoutPanelSolicitacoes.Location = new System.Drawing.Point(1067, 527);
            this.flowLayoutPanelSolicitacoes.Margin = new System.Windows.Forms.Padding(2);
            this.flowLayoutPanelSolicitacoes.Name = "flowLayoutPanelSolicitacoes";
            this.flowLayoutPanelSolicitacoes.Size = new System.Drawing.Size(213, 194);
            this.flowLayoutPanelSolicitacoes.TabIndex = 22;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(269, 149);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(198, 198);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel6.Location = new System.Drawing.Point(1062, 31);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(5, 690);
            this.panel6.TabIndex = 28;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel8.Location = new System.Drawing.Point(213, 32);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(5, 683);
            this.panel8.TabIndex = 29;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(1280, 715);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.flowLayoutPanelSolicitacoes);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.flowLayoutPanelAmigos);
            this.Controls.Add(this.nomeUsuario);
            this.Controls.Add(this.PostText);
            this.Controls.Add(this.new_post);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button new_post;
        private System.Windows.Forms.Panel PostText;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label nomeUsuario;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelAmigos;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btHome;
        private System.Windows.Forms.Button btMenu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btComunidade;
        private System.Windows.Forms.Button btSettings;
        private System.Windows.Forms.Button btAmigos;
        private System.Windows.Forms.Button btProfile;
        private System.Windows.Forms.RichTextBox textBoxNomeAmigo;
        private System.Windows.Forms.Button btnAdicionarAmigo;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelSolicitacoes;
        private System.Windows.Forms.Label textBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
    }
}