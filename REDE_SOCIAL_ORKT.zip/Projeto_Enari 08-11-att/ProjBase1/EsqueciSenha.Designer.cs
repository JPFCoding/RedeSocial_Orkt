﻿namespace ProjBase1
{
    partial class EsqueciSenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextCodigo = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MandarCodigo = new System.Windows.Forms.Button();
            this.Fechar = new System.Windows.Forms.Button();
            this.verificar = new System.Windows.Forms.Button();
            this.novasenha = new System.Windows.Forms.TextBox();
            this.Confirmar = new System.Windows.Forms.Button();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // richTextCodigo
            // 
            this.richTextCodigo.Location = new System.Drawing.Point(196, 192);
            this.richTextCodigo.Name = "richTextCodigo";
            this.richTextCodigo.Size = new System.Drawing.Size(400, 81);
            this.richTextCodigo.TabIndex = 0;
            this.richTextCodigo.Text = "";
            this.richTextCodigo.TextChanged += new System.EventHandler(this.richTextCodigo_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(267, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Deseja enviar um codigo para o seu email?";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // MandarCodigo
            // 
            this.MandarCodigo.Location = new System.Drawing.Point(351, 59);
            this.MandarCodigo.Name = "MandarCodigo";
            this.MandarCodigo.Size = new System.Drawing.Size(131, 54);
            this.MandarCodigo.TabIndex = 2;
            this.MandarCodigo.Text = "Sim";
            this.MandarCodigo.UseVisualStyleBackColor = true;
            this.MandarCodigo.Click += new System.EventHandler(this.MandarCodigo_Click);
            // 
            // Fechar
            // 
            this.Fechar.Location = new System.Drawing.Point(512, 59);
            this.Fechar.Name = "Fechar";
            this.Fechar.Size = new System.Drawing.Size(131, 54);
            this.Fechar.TabIndex = 3;
            this.Fechar.Text = "Não";
            this.Fechar.UseVisualStyleBackColor = true;
            this.Fechar.Click += new System.EventHandler(this.Fechar_Click);
            // 
            // verificar
            // 
            this.verificar.Location = new System.Drawing.Point(322, 279);
            this.verificar.Name = "verificar";
            this.verificar.Size = new System.Drawing.Size(131, 54);
            this.verificar.TabIndex = 4;
            this.verificar.Text = "Verificar";
            this.verificar.UseVisualStyleBackColor = true;
            this.verificar.Click += new System.EventHandler(this.verificar_Click);
            // 
            // novasenha
            // 
            this.novasenha.Location = new System.Drawing.Point(251, 350);
            this.novasenha.Name = "novasenha";
            this.novasenha.Size = new System.Drawing.Size(276, 22);
            this.novasenha.TabIndex = 5;
            this.novasenha.TextChanged += new System.EventHandler(this.novasenha_TextChanged);
            // 
            // Confirmar
            // 
            this.Confirmar.Location = new System.Drawing.Point(322, 384);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(131, 54);
            this.Confirmar.TabIndex = 6;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(57, 75);
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(276, 22);
            this.textEmail.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(271, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Digite o código aqui";
            // 
            // EsqueciSenha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textEmail);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.novasenha);
            this.Controls.Add(this.verificar);
            this.Controls.Add(this.Fechar);
            this.Controls.Add(this.MandarCodigo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextCodigo);
            this.Name = "EsqueciSenha";
            this.Text = "EsqueciSenha";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextCodigo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button MandarCodigo;
        private System.Windows.Forms.Button Fechar;
        private System.Windows.Forms.Button verificar;
        private System.Windows.Forms.TextBox novasenha;
        private System.Windows.Forms.Button Confirmar;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.Label label2;
    }
}