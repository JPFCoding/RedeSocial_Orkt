﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using static ProjBase1.Form4;


namespace ProjBase1
{
    
    public partial class Form3 : Form
    {
        public class DadosGlobal1
        {
            public static List<Postagem> FeedGeral { get; set; } = new List<Postagem>();
        }
        public Form3()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Orkit";

        }

        public class Postagem
        {
            public string Post { get; set; }
            public Image Imagem { get; set; }
            public List<string> Comentarios { get; set; } = new List<string>();
            public List<string> UsuariosQueCurtiram { get; set; } = new List<string>();
            public string Autor { get; set; }
            public List<Postagem> Posts { get; set; } = new List<Postagem>();


            // Construtor para inicializar a postagem
            public Postagem(string post, Image imagem, string autor)
            {
                Post = post;
                Imagem = imagem;
                Autor = autor;
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
            if (DadosUsuario.UsuarioLogado != null && !string.IsNullOrEmpty(DadosUsuario.UsuarioLogado.Nome))
            {
                textBox1.Text = DadosUsuario.UsuarioLogado.Nome;
            }
            else
            {
                MessageBox.Show("Usuário não logado.");
                this.Hide();
                Form1 form = new Form1();
                form.Show();
            }

            AtualizarFeedGeral();

            if (DadosUsuario.UsuarioLogado.FotoPerfil != null)
            {
                pictureBox1.Image = DadosUsuario.UsuarioLogado.FotoPerfil;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            flowLayoutPanelAmigos.Controls.Clear();
            CarregarAmigos();
            CarregarSolicitacoesPendentes();

            comboBoxFiltro.Items.Add("Geral");
            comboBoxFiltro.Items.Add("Amigos");
            comboBoxFiltro.SelectedIndex = 0; // Define "Geral" como padrão
            comboBoxFiltro.SelectedIndexChanged += ComboBoxFiltro_SelectedIndexChanged;
            AtualizarFeedGeral();

        }


        private void btProfile_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 f4 = new Form4();
            f4.Show(); 

            /*
            using (Form4 form = new Form4())
            {
                form.ShowDialog();
            }

            this.Show();
            */

            AtualizarPosts();
            AtualizarFeedGeral();
            if (DadosUsuario.UsuarioLogado.FotoPerfil != null)
            {
                pictureBox1.Image = DadosUsuario.UsuarioLogado.FotoPerfil;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void LimparDadosUsuario()
        {
            DadosUsuario.UsuarioLogado.Posts.Clear();
            DadosUsuario.UsuarioLogado.Imagens.Clear();

        }

        private void Logoff_Click(object sender, EventArgs e)
        {
            // Verifica se há um usuário logado antes de deslogar
            if (DadosUsuario.UsuarioLogado != null)
            {
                // Armazena o estado atual dos posts e imagens do usuário
                string nomeUsuario = DadosUsuario.UsuarioLogado.Nome;
                if (DadosUsuario.Usuarios.ContainsKey(nomeUsuario))
                {
                    DadosUsuario.Usuarios[nomeUsuario] = DadosUsuario.UsuarioLogado;
                }

                // Desassocia o usuário logado
                DadosUsuario.UsuarioLogado = null;
                flowLayoutPanelAmigos.Controls.Clear();

            }

            // Esconde a tela atual e abre a tela de login novamente
            this.Hide();
            Form1 form = new Form1();
            form.ShowDialog();
            this.Close();
        }


        private void AtualizarFeedGeral()
        {
            PostText.Controls.Clear();

            var amigos = DadosUsuario.UsuarioLogado.Amigos.Select(amigo => amigo.Nome).ToList();
            List<Postagem> feedFiltrado;

            if (comboBoxFiltro.SelectedItem != null && comboBoxFiltro.SelectedItem.ToString() == "Amigos")
            {
                feedFiltrado = DadosGlobal1.FeedGeral.Where(post => amigos.Contains(post.Autor)).ToList();
            }
            else
            {
                feedFiltrado = DadosGlobal1.FeedGeral;
            }

            // Reverte a ordem dos posts
            feedFiltrado = feedFiltrado.AsEnumerable().Reverse().ToList();

            int currentPostTop = 10; // Posição inicial para o primeiro post

            foreach (var post in feedFiltrado)
            {
                // Define a altura do painel principal, ajustável conforme necessário
                int postPanelHeight = post.Imagem != null ? 300 : 220;

                // Cria o painel para cada postagem
                Panel postPanel = new Panel
                {
                    Width = PostText.Width - 40,
                    Height = postPanelHeight,
                    Padding = new Padding(15),
                    Margin = new Padding(10, 10, 10, 10),
                    BackColor = Color.FromArgb(40, 40, 40),
                    BorderStyle = BorderStyle.None,
                    Location = new Point(10, currentPostTop) // Define a posição vertical do post
                };

                // Autor da postagem
                Label autorLabel = new Label
                {
                    Text = post.Autor ?? "Autor desconhecido",
                    AutoSize = true,
                    Location = new Point(10, 10),
                    Font = new Font("Microsoft Sans Serif", 11, FontStyle.Italic),
                    ForeColor = Color.LightGray
                };
                postPanel.Controls.Add(autorLabel);

                // Texto da postagem
                Label postLabel = new Label
                {
                    Text = post.Post,
                    Location = new Point(10, 30),
                    MaximumSize = new Size(postPanel.Width - 20, 0),
                    Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold),
                    ForeColor = Color.White,
                    AutoSize = true
                };
                postPanel.Controls.Add(postLabel);

                // Imagem centralizada e aumentada, se houver
                if (post.Imagem != null)
                {
                    PictureBox postImage = new PictureBox
                    {
                        Image = post.Imagem,
                        SizeMode = PictureBoxSizeMode.Zoom,
                        Size = new Size(postPanel.Width - 40, 140), // Ajuste o tamanho conforme necessário
                        Location = new Point(20, 70),
                        BorderStyle = BorderStyle.FixedSingle,
                        BackColor = Color.FromArgb(50, 50, 50)
                    };
                    postPanel.Controls.Add(postImage);
                }

                // Contador de Likes destacado entre o conteúdo e os comentários
                Label likeCountLabel = new Label
                {
                    Text = $"👍🏿 Curtidas: {post.UsuariosQueCurtiram.Count}",
                    AutoSize = true,
                    Location = post.Imagem != null ? new Point(10, 220) : new Point(10, 100),
                    Font = new Font("Microsoft Sans Serif", 11, FontStyle.Bold),
                    ForeColor = Color.White,
                    BackColor = Color.FromArgb(30, 30, 30),
                    Padding = new Padding(5, 2, 5, 2)
                };
                postPanel.Controls.Add(likeCountLabel);

                // Botão de Curtir
                Button likeButton = new Button
                {
                    Text = post.UsuariosQueCurtiram.Contains(DadosUsuario.UsuarioLogado.Nome) ? "👍 Curtido" : "👍 Curtir",
                    BackColor = post.UsuariosQueCurtiram.Contains(DadosUsuario.UsuarioLogado.Nome) ? Color.FromArgb(255, 128, 0) : Color.Gray,
                    ForeColor = Color.White,
                    Height = 30,
                    Width = 80,
                    Location = new Point(postPanel.Width - 100, post.Imagem != null ? 215 : 90), // Posiciona o botão ao lado do contador de likes
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold),
                    Cursor = Cursors.Hand
                };
                likeButton.FlatAppearance.BorderSize = 0;
                likeButton.Cursor = Cursors.Hand;

                likeButton.Click += (s, e) =>
                {
                    if (post.UsuariosQueCurtiram.Contains(DadosUsuario.UsuarioLogado.Nome))
                    {
                        post.UsuariosQueCurtiram.Remove(DadosUsuario.UsuarioLogado.Nome);
                        likeButton.Text = "👍 Curtir";
                        likeButton.BackColor = Color.Gray;
                    }
                    else
                    {
                        post.UsuariosQueCurtiram.Add(DadosUsuario.UsuarioLogado.Nome);
                        likeButton.Text = "👍 Curtido";
                        likeButton.BackColor = Color.FromArgb(255, 128, 0);
                    }
                    likeCountLabel.Text = $"👍 Curtidas: {post.UsuariosQueCurtiram.Count}";
                };
                postPanel.Controls.Add(likeButton);

                // Botão de Comentar
                Button commentButton = new Button
                {
                    Text = "Comentar",
                    BackColor = Color.DarkGray,
                    ForeColor = Color.White,
                    Height = 30,
                    Width = 90,
                    Location = new Point(postPanel.Width - 200, post.Imagem != null ? 215 : 90),
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold),
                    Cursor = Cursors.Hand
                };
                commentButton.FlatAppearance.BorderSize = 0;
                commentButton.Cursor = Cursors.Hand;

                commentButton.Click += (s, e) =>
                {
                    using (var commentForm = new CommentForm(post.Comentarios))
                    {
                        if (commentForm.ShowDialog() == DialogResult.OK)
                        {
                            MessageBox.Show("Comentário adicionado!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            AtualizarFeedGeral();
                        }
                    }
                };
                postPanel.Controls.Add(commentButton);

                // Painel de comentários
                if (post.Comentarios.Any())
                {
                    Panel commentsPanel = new Panel
                    {
                        Location = post.Imagem != null ? new Point(10, 260) : new Point(10, 130),
                        Size = new Size(postPanel.Width - 30, 100), // Define altura máxima de 100 para o painel de comentários
                        BackColor = Color.FromArgb(50, 50, 50),
                        BorderStyle = BorderStyle.FixedSingle,
                        AutoScroll = true,
                        Padding = new Padding(5)
                    };

                    Label commentsLabel = new Label
                    {
                        Text = string.Join("\n", post.Comentarios),
                        AutoSize = true,
                        MaximumSize = new Size(commentsPanel.Width - 10, 0),
                        Font = new Font("Microsoft Sans Serif", 12),
                        ForeColor = Color.LightGray
                    };
                    commentsPanel.Controls.Add(commentsLabel);
                    postPanel.Controls.Add(commentsPanel);
                }

                // Linha divisória entre posts
                Panel separatorPanel = new Panel
                {
                    Size = new Size(postPanel.Width - 20, 1),
                    Location = new Point(10, postPanelHeight - 2),
                    BackColor = Color.FromArgb(60, 60, 60)
                };
                postPanel.Controls.Add(separatorPanel);

                // Adiciona o painel de postagem ao controle principal
                PostText.Controls.Add(postPanel);

                // Atualiza a posição do próximo post
                currentPostTop += postPanelHeight + 20; // Adiciona 20 de margem entre os posts
            }
        }


        // Método para atualizar o feed quando o filtro muda
        private void ComboBoxFiltro_SelectedIndexChanged(object sender, EventArgs e)
        {
            AtualizarFeedGeral();
        }

        private void AtualizarPosts()
        {
            PostText.Controls.Clear();
            int yPosition = 10;
            int postPanelHeight = 120;

            /* 
            if (DadosUsuario.UsuarioLogado.Posts.Count != DadosUsuario.UsuarioLogado.Imagens.Count)
            {
                MessageBox.Show("Erro: O número de posts e imagens não coincide.");
                return;
            }
            */

            for (int i = DadosUsuario.UsuarioLogado.Posts.Count - 1; i >= 0; i--)
            {
                var post = DadosUsuario.UsuarioLogado.Posts[i];
                var img = DadosUsuario.UsuarioLogado.Imagens[i];

                Panel postPanel = new Panel
                {
                    Size = new Size(PostText.Width - 20, postPanelHeight),
                    Location = new Point(10, yPosition),
                    BorderStyle = BorderStyle.FixedSingle
                };

                PictureBox postImage = new PictureBox
                {
                    Image = img,
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    Size = new Size(100, 100),
                    Location = new Point(10, 10)
                };

                Label postLabel = new Label
                {
                    Text = post,
                    AutoSize = true,
                    Location = new Point(120, 10),
                    MaximumSize = new Size(postPanel.Width - 130, 0)
                };

                postPanel.Controls.Add(postImage);
                postPanel.Controls.Add(postLabel);
                PostText.Controls.Add(postPanel);
                yPosition += postPanelHeight + 10;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form6 form6 = new Form6();
            form6.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private void btnAdicionarAmigo_Click(object sender, EventArgs e)
        {
            string nomeAmigo = textBoxNomeAmigo.Text.Trim();

            if (!string.IsNullOrEmpty(nomeAmigo))
            {
                // Verifica se o nome inserido é o mesmo do usuário logado
                if (nomeAmigo.Equals(DadosUsuario.UsuarioLogado.Nome, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Você não pode enviar uma solicitação de amizade para si mesmo.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Impede que o restante do código seja executado
                }

                // Verifica se o amigo existe no dicionário
                if (DadosUsuario.Usuarios.TryGetValue(nomeAmigo, out var amigo))
                {
                    // Adiciona a solicitação na lista de pendentes do amigo
                    if (!amigo.SolicitacoesPendentes.Contains(DadosUsuario.UsuarioLogado.Nome))
                    {
                        amigo.SolicitacoesPendentes.Add(DadosUsuario.UsuarioLogado.Nome);
                        MessageBox.Show("Solicitação de amizade enviada!", "Sucesso", MessageBoxButtons.OK);
                        textBoxNomeAmigo.Clear();
                        panelAddFriend.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Você já enviou uma solicitação para esse usuário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Amigo não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o nome do amigo.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }



        private void ExibirAmigoNoPanel(string nome, Image foto)
        {
            Refresh();
            Button amigoButton = new Button
            {
                Size = new Size(100, 100),
                TextAlign = ContentAlignment.BottomCenter,
                TextImageRelation = TextImageRelation.ImageAboveText,
                BackColor = Color.White
            };

            if (foto != null)
            {
                Image imagemReduzida = RedimensionarImagem(foto, 70, 70);
                amigoButton.Image = imagemReduzida;
                amigoButton.ImageAlign = ContentAlignment.TopCenter;
                amigoButton.Text = nome;
            }
            else
            {
                amigoButton.Text = nome;
            }

            amigoButton.Click += (sender, e) =>
            {
                
                OpenChatForm(nome, foto);
                this.Close();
            };
            flowLayoutPanelAmigos.Controls.Add(amigoButton);
        }

        private Image RedimensionarImagem(Image img, int largura, int altura)
        {
            Bitmap bmp = new Bitmap(largura, altura);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.DrawImage(img, 0, 0, largura, altura);
            }
            return bmp;
        }

        private void OpenChatForm(string nomeAmigo, Image fotoAmigo)
        {
            
            ChatForm chatForm = new ChatForm(nomeAmigo, fotoAmigo, Form3.DadosGlobal1.FeedGeral);
            chatForm.Show();
        }



        private void CarregarAmigos()
        {
            Refresh();
            // Limpa os amigos exibidos anteriormente para evitar duplicações
            flowLayoutPanelAmigos.Controls.Clear();

            // Verifica se o usuário tem amigos
            if (DadosUsuario.UsuarioLogado.Amigos != null)
            {
                foreach (var amigo in DadosUsuario.UsuarioLogado.Amigos)
                {
                    // Verifica se a foto do amigo não é nula
                    if (amigo.FotoPerfil != null)
                    {
                        // Chame a função para exibir o amigo com foto
                        ExibirAmigoNoPanel(amigo.Nome, amigo.FotoPerfil);
                    }
                    else
                    {
                        // Chame a função para exibir o amigo sem foto
                        ExibirAmigoNoPanel(amigo.Nome, null); // Ou utilize uma imagem padrão
                    }
                }
            }
        }


        private void btComunidade_Click(object sender, EventArgs e)
        {
            this.Close();
            Community community = new Community();
            community.Show();
            
        }

        private void CarregarSolicitacoesPendentes()
        {
            flowLayoutPanelSolicitacoes.Controls.Clear();

            foreach (var nomeSolicitante in DadosUsuario.UsuarioLogado.SolicitacoesPendentes)
            {
                // Cria um painel para cada solicitação
                Panel solicitacaoPanel = new Panel
                {
                    Size = new Size(200, 50),
                    BorderStyle = BorderStyle.FixedSingle,
                    BackColor = Color.White

                };

                Label labelNome = new Label
                {
                    Text = nomeSolicitante,
                    AutoSize = true,
                    Location = new Point(10, 15)
                };

                Button aceitarButton = new Button
                {
                    Text = "Aceitar",
                    Size = new Size(60, 25),
                    Location = new Point(50, 10)
                };

                Button recusarButton = new Button
                {
                    Text = "Recusar",
                    Size = new Size(60, 25),
                    Location = new Point(120, 10)
                };

                aceitarButton.Click += (s, e) =>
                {
                    // Aceita a solicitação
                    if (DadosUsuario.Usuarios.TryGetValue(nomeSolicitante, out var solicitante))
                    {
                        DadosUsuario.UsuarioLogado.Amigos.Add(solicitante);
                        solicitante.Amigos.Add(DadosUsuario.UsuarioLogado);
                        //MessageBox.Show($"{nomeSolicitante} agora é seu amigo!", "Sucesso", MessageBoxButtons.OK);
                        CarregarAmigos();
                        this.Refresh();
                    }

                    // Remove a solicitação da lista
                    DadosUsuario.UsuarioLogado.SolicitacoesPendentes.Remove(nomeSolicitante);
                    CarregarSolicitacoesPendentes();
                };

                recusarButton.Click += (s, e) =>
                {
                    // Recusa a solicitação
                    DadosUsuario.UsuarioLogado.SolicitacoesPendentes.Remove(nomeSolicitante);
                    CarregarSolicitacoesPendentes();
                };

                // Adiciona os controles ao painel e o painel ao FlowLayoutPanel
                solicitacaoPanel.Controls.Add(labelNome);
                solicitacaoPanel.Controls.Add(aceitarButton);
                solicitacaoPanel.Controls.Add(recusarButton);
                flowLayoutPanelSolicitacoes.Controls.Add(solicitacaoPanel);
            }
        }

        private void btSettings_Click(object sender, EventArgs e)
        {
            ConfigForm configForm = new ConfigForm();
            configForm.ShowDialog();
        }

        private void AtualizarFeedAmigos()
        {
            PostText.Controls.Clear();
            int yPosition = 10;
            int postPanelHeight = 160;

            var amigosNomes = DadosUsuario.UsuarioLogado.Amigos.Select(a => a.Nome).ToList();

            foreach (var post in DadosGlobal1.FeedGeral.Where(p => amigosNomes.Contains(p.Autor)))
            {
                Panel postPanel = new Panel
                {
                    Size = new Size(PostText.Width - 20, postPanelHeight),
                    Location = new Point(10, yPosition),
                    BorderStyle = BorderStyle.FixedSingle
                };

                PictureBox postImage = new PictureBox
                {
                    Image = post.Imagem,
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    Size = new Size(100, 100),
                    Location = new Point(10, 10)
                };

                Label postLabel = new Label
                {
                    Text = post.Post,
                    AutoSize = true,
                    Location = new Point(120, 10),
                    MaximumSize = new Size(postPanel.Width - 130, 0),
                    Font = new Font("Arial", 14, FontStyle.Bold)
                };

                // Adiciona controles ao painel e ao PostText
                postPanel.Controls.Add(postImage);
                postPanel.Controls.Add(postLabel);
                PostText.Controls.Add(postPanel);

                yPosition += postPanelHeight + 10;
            }
        }


        private void PostText_Paint(object sender, EventArgs e)
        {

        }

        private void comboBoxFiltro_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btAmigos_Click(object sender, EventArgs e)
        {
            panelAddFriend.Visible = true;
        }

        private void btNotification_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Verifica se há um usuário logado antes de deslogar
            if (DadosUsuario.UsuarioLogado != null)
            {
                // Armazena o estado atual dos posts e imagens do usuário
                string nomeUsuario = DadosUsuario.UsuarioLogado.Nome;
                if (DadosUsuario.Usuarios.ContainsKey(nomeUsuario))
                {
                    DadosUsuario.Usuarios[nomeUsuario] = DadosUsuario.UsuarioLogado;
                }

                // Desassocia o usuário logado
                DadosUsuario.UsuarioLogado = null;
                flowLayoutPanelAmigos.Controls.Clear();

            }

            // Esconde a tela atual e abre a tela de login novamente
            this.Hide();
            Form1 form = new Form1();
            form.ShowDialog();
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btHome_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanelAmigos_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}