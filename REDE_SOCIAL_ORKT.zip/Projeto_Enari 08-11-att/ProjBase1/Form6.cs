﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using static ProjBase1.Form3;
using static ProjBase1.Form4;

namespace ProjBase1
{
    public partial class Form6 : Form
    {
        private int correctAnswer;
        private int score = 0;
        private string currentOperation;
        private Timer timer; 

        public Form6()
        {
            InitializeComponent();
            GenerateQuestion();
            op1.Click += new EventHandler(op1_Click);
            op2.Click += new EventHandler(op2_Click);
            op3.Click += new EventHandler(op3_Click);
            this.StartPosition = FormStartPosition.CenterScreen;
            timer = new Timer();
            timer.Interval = 1000; 
            timer.Tick += Timer_Tick;
            labelScore1.Visible = false;

        }

        private void GenerateQuestion()
        {
            op1.BackColor = SystemColors.Control; 
            op2.BackColor = SystemColors.Control;
            op3.BackColor = SystemColors.Control;

            // Gera uma nova pergunta
            Random random = new Random();
            int num1 = random.Next(1, 10);
            int num2 = random.Next(1, 10);
            int operationType = random.Next(0, 4);

            switch (operationType)
            {
                case 0:
                    correctAnswer = num1 + num2;
                    currentOperation = "+";
                    break;
                case 1:
                    correctAnswer = num1 - num2;
                    currentOperation = "-";
                    break;
                case 2:
                    correctAnswer = num1 * num2;
                    currentOperation = "*";
                    break;
                case 3:
                    while (num2 == 0 || num1 % num2 != 0)
                    {
                        num1 = random.Next(1, 10);
                        num2 = random.Next(1, 10);
                    }
                    correctAnswer = num1 / num2;
                    currentOperation = "/";
                    break;
            }

            richTextBox1.Text = $"Quanto é {num1} {currentOperation} {num2}?";

            int[] options = new int[3];
            int correctOption = random.Next(0, 3);
            options[correctOption] = correctAnswer; // Atribui a resposta correta

            for (int i = 0; i < 3; i++)
            {
                if (i != correctOption)
                {
                    int wrongAnswer;
                    do
                    {
                        wrongAnswer = random.Next(1, 20); // Gera uma resposta errada
                    } while (wrongAnswer == correctAnswer || Array.Exists(options, element => element == wrongAnswer));

                    options[i] = wrongAnswer; // Atribui uma resposta errada
                }
            }

            op1.Text = options[0].ToString();
            op2.Text = options[1].ToString();
            op3.Text = options[2].ToString();
        }

        private void CheckAnswer(int selectedAnswer)
        {
            // Desabilita os botões para prevenir múltiplos cliques
            op1.Enabled = false;
            op2.Enabled = false;
            op3.Enabled = false;

            // Verifica se a resposta está correta
            if (selectedAnswer == correctAnswer)
            {
                score = score+1;
                HighlightCorrectButton(selectedAnswer);
                timer.Start();
            }
            else
            {
                HighlightWrongAndCorrectButtons(selectedAnswer);
                score = 0;
                timer.Start();
            }

            UpdateScore(); // Atualiza a pontuação
        }


        private void HighlightCorrectButton(int selectedAnswer)
        {
            // Destaca o botão correto
            if (selectedAnswer == int.Parse(op1.Text))
            {
                op1.BackColor = Color.Green;
            }
            else if (selectedAnswer == int.Parse(op2.Text))
            {
                op2.BackColor = Color.Green;
            }
            else if (selectedAnswer == int.Parse(op3.Text))
            {
                op3.BackColor = Color.Green;
            }

            // Gera nova pergunta após 1 segundo
            timer.Interval = 700; // 1 segundo
            //timer.Start();
        }

        private void HighlightWrongAndCorrectButtons(int selectedAnswer)
        {
            // Destaca o botão incorreto
            if (selectedAnswer == int.Parse(op1.Text))
            {
                op1.BackColor = Color.Red;
            }
            else if (selectedAnswer == int.Parse(op2.Text))
            {
                op2.BackColor = Color.Red;
            }
            else if (selectedAnswer == int.Parse(op3.Text))
            {
                op3.BackColor = Color.Red;
            }

            // Destaca o botão correto
            if (correctAnswer == int.Parse(op1.Text))
            {
                op1.BackColor = Color.Green;
            }
            else if (correctAnswer == int.Parse(op2.Text))
            {
                op2.BackColor = Color.Green;
            }
            else if (correctAnswer == int.Parse(op3.Text))
            {
                op3.BackColor = Color.Green;
            }
        }


        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop(); // Para o temporizador
            GenerateQuestion(); // Gera uma nova pergunta
            op1.Enabled = true;
            op2.Enabled = true;
            op3.Enabled = true;
        }

        private void UpdateScore()
        {
            labelScore1.Visible = true;
            labelScore.ForeColor = Color.White;
            labelScore1.Text = $"Pontuação: {score}"; // Exibe a pontuação atual
        }

        private void op1_Click(object sender, EventArgs e)
        {
            int selectedAnswer;
            if (int.TryParse(op1.Text, out selectedAnswer))
            {
                CheckAnswer(selectedAnswer);
            }
            else
            {
                MessageBox.Show("Erro na conversão da resposta.");
            }
        }

        private void op2_Click(object sender, EventArgs e)
        {
            int selectedAnswer;
            if (int.TryParse(op2.Text, out selectedAnswer))
            {
                CheckAnswer(selectedAnswer);
            }
            else
            {
                MessageBox.Show("Erro na conversão da resposta.");
            }
        }

        private void op3_Click(object sender, EventArgs e)
        {
            int selectedAnswer;
            if (int.TryParse(op3.Text, out selectedAnswer))
            {
                CheckAnswer(selectedAnswer);
            }
            else
            {
                MessageBox.Show("Erro na conversão da resposta.");
            }
        }

        private void home_Click(object sender, EventArgs e)
        {
            {
                Form3 form3 = Application.OpenForms.OfType<Form3>().FirstOrDefault();
                if (form3 != null)
                {
                    form3.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Erro: O feed não foi encontrado.");
                }
            }

        }

        private void btProfile_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 f4 = new Form4();
            f4.Show();

            //AtualizarPosts();
            //AtualizarFeedGeral();
            if (DadosUsuario.UsuarioLogado.FotoPerfil != null)
            {
                pictureBox1.Image = DadosUsuario.UsuarioLogado.FotoPerfil;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void btHome_Click(object sender, EventArgs e)
        {
            this.Close();
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            CarregarAmigos();
        }

        private void btComunidade_Click(object sender, EventArgs e)
        {
            this.Close();
            Community community = new Community();
            community.Show();
            
        }

        private void btAmigos_Click(object sender, EventArgs e)
        {
            panelAddFriend.Visible = true;
        }

        private void btnAdicionarAmigo_Click(object sender, EventArgs e)
        {
            string nomeAmigo = textBoxNomeAmigo.Text.Trim();

            if (!string.IsNullOrEmpty(nomeAmigo))
            {
                if (DadosUsuario.Usuarios.TryGetValue(nomeAmigo, out var amigo))
                {
                    // Adiciona a solicitação na lista de pendentes do amigo
                    if (!amigo.SolicitacoesPendentes.Contains(DadosUsuario.UsuarioLogado.Nome))
                    {
                        amigo.SolicitacoesPendentes.Add(DadosUsuario.UsuarioLogado.Nome);
                        MessageBox.Show("Solicitação de amizade enviada!", "Sucesso", MessageBoxButtons.OK);
                        textBoxNomeAmigo.Clear();
                        panelAddFriend.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Você já enviou uma solicitação para esse usuário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Amigo não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o nome do amigo.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ExibirAmigoNoPanel(string nome, Image foto)
        {
            Refresh();
            Button amigoButton = new Button
            {
                Size = new Size(100, 100),
                TextAlign = ContentAlignment.BottomCenter,
                TextImageRelation = TextImageRelation.ImageAboveText,
                BackColor = Color.White
            };

            if (foto != null)
            {
                Image imagemReduzida = RedimensionarImagem(foto, 70, 70);
                amigoButton.Image = imagemReduzida;
                amigoButton.ImageAlign = ContentAlignment.TopCenter;
                amigoButton.Text = nome;
            }
            else
            {
                amigoButton.Text = nome;
            }

            amigoButton.Click += (sender, e) =>
            {
                OpenChatForm(nome, foto);
                this.Close();
            };
            flowLayoutPanelAmigos.Controls.Add(amigoButton);
        }

        private Image RedimensionarImagem(Image img, int largura, int altura)
        {
            Bitmap bmp = new Bitmap(largura, altura);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.DrawImage(img, 0, 0, largura, altura);
            }
            return bmp;
        }

        private void OpenChatForm(string nomeAmigo, Image fotoAmigo)
        {
            ChatForm chatForm = new ChatForm(nomeAmigo, fotoAmigo, Form3.DadosGlobal1.FeedGeral);
            chatForm.Show();
        }



        private void CarregarAmigos()
        {
            Refresh();
            // Limpa os amigos exibidos anteriormente para evitar duplicações
            flowLayoutPanelAmigos.Controls.Clear();

            // Verifica se o usuário tem amigos
            if (DadosUsuario.UsuarioLogado.Amigos != null)
            {
                foreach (var amigo in DadosUsuario.UsuarioLogado.Amigos)
                {
                    // Verifica se a foto do amigo não é nula
                    if (amigo.FotoPerfil != null)
                    {
                        // Chame a função para exibir o amigo com foto
                        ExibirAmigoNoPanel(amigo.Nome, amigo.FotoPerfil);
                    }
                    else
                    {
                        // Chame a função para exibir o amigo sem foto
                        ExibirAmigoNoPanel(amigo.Nome, null); // Ou utilize uma imagem padrão
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Verifica se há um usuário logado antes de deslogar
            if (DadosUsuario.UsuarioLogado != null)
            {
                // Armazena o estado atual dos posts e imagens do usuário
                string nomeUsuario = DadosUsuario.UsuarioLogado.Nome;
                if (DadosUsuario.Usuarios.ContainsKey(nomeUsuario))
                {
                    DadosUsuario.Usuarios[nomeUsuario] = DadosUsuario.UsuarioLogado;
                }

                // Desassocia o usuário logado
                DadosUsuario.UsuarioLogado = null;
                flowLayoutPanelAmigos.Controls.Clear();

            }

            // Esconde a tela atual e abre a tela de login novamente
            this.Hide();
            Form1 form = new Form1();
            form.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanelAmigos_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    

}
