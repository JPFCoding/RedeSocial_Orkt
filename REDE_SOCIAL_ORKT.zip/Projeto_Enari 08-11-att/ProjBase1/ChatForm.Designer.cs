﻿namespace ProjBase1
{
    partial class ChatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelNomeAmigo = new System.Windows.Forms.Label();
            this.textBoxMensagem = new System.Windows.Forms.TextBox();
            this.flowLayoutPanelPostagens = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanelMensagens = new System.Windows.Forms.FlowLayoutPanel();
            this.buttontEnviar = new System.Windows.Forms.Button();
            this.verChat = new System.Windows.Forms.Button();
            this.Perfil = new System.Windows.Forms.Button();
            this.excluirAmigo = new System.Windows.Forms.Button();
            this.pictureBoxFotoAmigo = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.btHome = new System.Windows.Forms.Button();
            this.btMenu = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btComunidade = new System.Windows.Forms.Button();
            this.btSettings = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btAmigos = new System.Windows.Forms.Button();
            this.btProfile = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanelAmigos = new System.Windows.Forms.FlowLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanelSolicitacoes = new System.Windows.Forms.FlowLayoutPanel();
            this.panelAddFriend = new System.Windows.Forms.Panel();
            this.textBoxNomeAmigo = new System.Windows.Forms.RichTextBox();
            this.btnAdicionarAmigo = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFotoAmigo)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panelAddFriend.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // labelNomeAmigo
            // 
            this.labelNomeAmigo.AutoSize = true;
            this.labelNomeAmigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.labelNomeAmigo.ForeColor = System.Drawing.SystemColors.Window;
            this.labelNomeAmigo.Location = new System.Drawing.Point(387, 119);
            this.labelNomeAmigo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelNomeAmigo.Name = "labelNomeAmigo";
            this.labelNomeAmigo.Size = new System.Drawing.Size(86, 31);
            this.labelNomeAmigo.TabIndex = 3;
            this.labelNomeAmigo.Text = "label1";
            this.labelNomeAmigo.Click += new System.EventHandler(this.labelNomeAmigo_Click);
            // 
            // textBoxMensagem
            // 
            this.textBoxMensagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxMensagem.Location = new System.Drawing.Point(227, 353);
            this.textBoxMensagem.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.textBoxMensagem.Name = "textBoxMensagem";
            this.textBoxMensagem.Size = new System.Drawing.Size(256, 26);
            this.textBoxMensagem.TabIndex = 5;
            // 
            // flowLayoutPanelPostagens
            // 
            this.flowLayoutPanelPostagens.AutoScroll = true;
            this.flowLayoutPanelPostagens.Location = new System.Drawing.Point(280, 200);
            this.flowLayoutPanelPostagens.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.flowLayoutPanelPostagens.Name = "flowLayoutPanelPostagens";
            this.flowLayoutPanelPostagens.Size = new System.Drawing.Size(722, 379);
            this.flowLayoutPanelPostagens.TabIndex = 6;
            this.flowLayoutPanelPostagens.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanelPostagens_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.flowLayoutPanelMensagens);
            this.panel1.Controls.Add(this.textBoxMensagem);
            this.panel1.Controls.Add(this.buttontEnviar);
            this.panel1.Location = new System.Drawing.Point(239, 188);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 417);
            this.panel1.TabIndex = 7;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // flowLayoutPanelMensagens
            // 
            this.flowLayoutPanelMensagens.AutoScroll = true;
            this.flowLayoutPanelMensagens.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanelMensagens.Location = new System.Drawing.Point(58, 43);
            this.flowLayoutPanelMensagens.Name = "flowLayoutPanelMensagens";
            this.flowLayoutPanelMensagens.Size = new System.Drawing.Size(667, 266);
            this.flowLayoutPanelMensagens.TabIndex = 6;
            this.flowLayoutPanelMensagens.WrapContents = false;
            // 
            // buttontEnviar
            // 
            this.buttontEnviar.Image = global::ProjBase1.Properties.Resources.icons8_enviar_30_1;
            this.buttontEnviar.Location = new System.Drawing.Point(495, 356);
            this.buttontEnviar.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.buttontEnviar.Name = "buttontEnviar";
            this.buttontEnviar.Size = new System.Drawing.Size(37, 22);
            this.buttontEnviar.TabIndex = 2;
            this.buttontEnviar.UseVisualStyleBackColor = true;
            this.buttontEnviar.Click += new System.EventHandler(this.buttonEnviar_Click);
            // 
            // verChat
            // 
            this.verChat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.verChat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.verChat.ForeColor = System.Drawing.SystemColors.Window;
            this.verChat.Location = new System.Drawing.Point(672, 139);
            this.verChat.Margin = new System.Windows.Forms.Padding(2);
            this.verChat.Name = "verChat";
            this.verChat.Size = new System.Drawing.Size(99, 36);
            this.verChat.TabIndex = 8;
            this.verChat.Text = "Abrir Chat";
            this.verChat.UseVisualStyleBackColor = false;
            this.verChat.Click += new System.EventHandler(this.verChat_Click);
            // 
            // Perfil
            // 
            this.Perfil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Perfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Perfil.ForeColor = System.Drawing.SystemColors.Window;
            this.Perfil.Location = new System.Drawing.Point(525, 138);
            this.Perfil.Margin = new System.Windows.Forms.Padding(2);
            this.Perfil.Name = "Perfil";
            this.Perfil.Size = new System.Drawing.Size(99, 36);
            this.Perfil.TabIndex = 9;
            this.Perfil.Text = "Ver Perfil";
            this.Perfil.UseVisualStyleBackColor = false;
            this.Perfil.Click += new System.EventHandler(this.Perfil_Click);
            // 
            // excluirAmigo
            // 
            this.excluirAmigo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.excluirAmigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.excluirAmigo.ForeColor = System.Drawing.SystemColors.Window;
            this.excluirAmigo.Location = new System.Drawing.Point(815, 139);
            this.excluirAmigo.Margin = new System.Windows.Forms.Padding(2);
            this.excluirAmigo.Name = "excluirAmigo";
            this.excluirAmigo.Size = new System.Drawing.Size(113, 35);
            this.excluirAmigo.TabIndex = 12;
            this.excluirAmigo.Text = "Excluir Amigo";
            this.excluirAmigo.UseVisualStyleBackColor = false;
            this.excluirAmigo.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBoxFotoAmigo
            // 
            this.pictureBoxFotoAmigo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxFotoAmigo.Location = new System.Drawing.Point(255, 45);
            this.pictureBoxFotoAmigo.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBoxFotoAmigo.Name = "pictureBoxFotoAmigo";
            this.pictureBoxFotoAmigo.Size = new System.Drawing.Size(111, 111);
            this.pictureBoxFotoAmigo.TabIndex = 10;
            this.pictureBoxFotoAmigo.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.btHome);
            this.panel2.Controls.Add(this.btMenu);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btComunidade);
            this.panel2.Controls.Add(this.btSettings);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.btAmigos);
            this.panel2.Controls.Add(this.btProfile);
            this.panel2.Location = new System.Drawing.Point(2, 33);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(212, 690);
            this.panel2.TabIndex = 18;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel8.Location = new System.Drawing.Point(207, -11);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(5, 715);
            this.panel8.TabIndex = 31;
            // 
            // textBox1
            // 
            this.textBox1.AutoSize = true;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(29, 228);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(0, 20);
            this.textBox1.TabIndex = 20;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = global::ProjBase1.Properties.Resources.icons8_logout_28;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 623);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(212, 53);
            this.button2.TabIndex = 12;
            this.button2.Text = "   Desconectar-se";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btHome
            // 
            this.btHome.FlatAppearance.BorderSize = 0;
            this.btHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHome.ForeColor = System.Drawing.Color.White;
            this.btHome.Image = global::ProjBase1.Properties.Resources.home_28;
            this.btHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btHome.Location = new System.Drawing.Point(0, 275);
            this.btHome.Name = "btHome";
            this.btHome.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btHome.Size = new System.Drawing.Size(212, 53);
            this.btHome.TabIndex = 9;
            this.btHome.Text = " Página Inicial";
            this.btHome.UseVisualStyleBackColor = true;
            this.btHome.Click += new System.EventHandler(this.btHome_Click);
            // 
            // btMenu
            // 
            this.btMenu.FlatAppearance.BorderSize = 0;
            this.btMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btMenu.ForeColor = System.Drawing.Color.White;
            this.btMenu.Image = global::ProjBase1.Properties.Resources.menu_28;
            this.btMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btMenu.Location = new System.Drawing.Point(0, 4);
            this.btMenu.Name = "btMenu";
            this.btMenu.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btMenu.Size = new System.Drawing.Size(212, 53);
            this.btMenu.TabIndex = 0;
            this.btMenu.Text = "Menu";
            this.btMenu.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = global::ProjBase1.Properties.Resources.icons8_game_28;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 495);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(212, 53);
            this.button1.TabIndex = 11;
            this.button1.Text = "      Jogos";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btComunidade
            // 
            this.btComunidade.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btComunidade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.btComunidade.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btComunidade.FlatAppearance.BorderSize = 0;
            this.btComunidade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btComunidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btComunidade.ForeColor = System.Drawing.Color.White;
            this.btComunidade.Image = global::ProjBase1.Properties.Resources.icons8_community_28;
            this.btComunidade.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btComunidade.Location = new System.Drawing.Point(0, 387);
            this.btComunidade.Name = "btComunidade";
            this.btComunidade.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btComunidade.Size = new System.Drawing.Size(212, 53);
            this.btComunidade.TabIndex = 0;
            this.btComunidade.Text = "   Comunidade";
            this.btComunidade.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btComunidade.UseVisualStyleBackColor = false;
            this.btComunidade.Click += new System.EventHandler(this.btComunidade_Click);
            // 
            // btSettings
            // 
            this.btSettings.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.btSettings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btSettings.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btSettings.FlatAppearance.BorderSize = 0;
            this.btSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSettings.ForeColor = System.Drawing.Color.White;
            this.btSettings.Image = global::ProjBase1.Properties.Resources.icons8_settings_28;
            this.btSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btSettings.Location = new System.Drawing.Point(0, 549);
            this.btSettings.Name = "btSettings";
            this.btSettings.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btSettings.Size = new System.Drawing.Size(212, 53);
            this.btSettings.TabIndex = 3;
            this.btSettings.Text = "   Configurações";
            this.btSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btSettings.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(33, 73);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(140, 140);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // btAmigos
            // 
            this.btAmigos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btAmigos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.btAmigos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btAmigos.FlatAppearance.BorderSize = 0;
            this.btAmigos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAmigos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAmigos.ForeColor = System.Drawing.Color.White;
            this.btAmigos.Image = global::ProjBase1.Properties.Resources.icons8_add_user_28;
            this.btAmigos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btAmigos.Location = new System.Drawing.Point(0, 441);
            this.btAmigos.Name = "btAmigos";
            this.btAmigos.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btAmigos.Size = new System.Drawing.Size(212, 53);
            this.btAmigos.TabIndex = 1;
            this.btAmigos.Text = "      Amigos";
            this.btAmigos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btAmigos.UseVisualStyleBackColor = false;
            this.btAmigos.Click += new System.EventHandler(this.btAmigos_Click);
            // 
            // btProfile
            // 
            this.btProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.btProfile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btProfile.FlatAppearance.BorderSize = 0;
            this.btProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btProfile.ForeColor = System.Drawing.Color.White;
            this.btProfile.Image = global::ProjBase1.Properties.Resources.icons8_user_28;
            this.btProfile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btProfile.Location = new System.Drawing.Point(0, 332);
            this.btProfile.Name = "btProfile";
            this.btProfile.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btProfile.Size = new System.Drawing.Size(212, 53);
            this.btProfile.TabIndex = 4;
            this.btProfile.Text = "        Perfil";
            this.btProfile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btProfile.UseVisualStyleBackColor = false;
            this.btProfile.Click += new System.EventHandler(this.btProfile_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Location = new System.Drawing.Point(1032, 31);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(249, 31);
            this.panel4.TabIndex = 22;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel6.Location = new System.Drawing.Point(-8, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(5, 693);
            this.panel6.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(43, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Lista de Amigos";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProjBase1.Properties.Resources.icons8_friends_28;
            this.pictureBox2.Location = new System.Drawing.Point(4, -1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 31);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // flowLayoutPanelAmigos
            // 
            this.flowLayoutPanelAmigos.AutoScroll = true;
            this.flowLayoutPanelAmigos.Location = new System.Drawing.Point(1032, 64);
            this.flowLayoutPanelAmigos.Margin = new System.Windows.Forms.Padding(2);
            this.flowLayoutPanelAmigos.Name = "flowLayoutPanelAmigos";
            this.flowLayoutPanelAmigos.Size = new System.Drawing.Size(248, 402);
            this.flowLayoutPanelAmigos.TabIndex = 21;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.pictureBox3);
            this.panel5.Location = new System.Drawing.Point(1031, 471);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(249, 31);
            this.panel5.TabIndex = 24;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(43, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Notificações";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ProjBase1.Properties.Resources.icons8_notification_28;
            this.pictureBox3.Location = new System.Drawing.Point(4, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 31);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // flowLayoutPanelSolicitacoes
            // 
            this.flowLayoutPanelSolicitacoes.AutoScroll = true;
            this.flowLayoutPanelSolicitacoes.Location = new System.Drawing.Point(1030, 499);
            this.flowLayoutPanelSolicitacoes.Margin = new System.Windows.Forms.Padding(2);
            this.flowLayoutPanelSolicitacoes.Name = "flowLayoutPanelSolicitacoes";
            this.flowLayoutPanelSolicitacoes.Size = new System.Drawing.Size(249, 219);
            this.flowLayoutPanelSolicitacoes.TabIndex = 23;
            // 
            // panelAddFriend
            // 
            this.panelAddFriend.Controls.Add(this.textBoxNomeAmigo);
            this.panelAddFriend.Controls.Add(this.btnAdicionarAmigo);
            this.panelAddFriend.Location = new System.Drawing.Point(528, 46);
            this.panelAddFriend.Name = "panelAddFriend";
            this.panelAddFriend.Size = new System.Drawing.Size(469, 76);
            this.panelAddFriend.TabIndex = 25;
            this.panelAddFriend.Visible = false;
            // 
            // textBoxNomeAmigo
            // 
            this.textBoxNomeAmigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNomeAmigo.Location = new System.Drawing.Point(17, 20);
            this.textBoxNomeAmigo.Name = "textBoxNomeAmigo";
            this.textBoxNomeAmigo.Size = new System.Drawing.Size(269, 26);
            this.textBoxNomeAmigo.TabIndex = 19;
            this.textBoxNomeAmigo.Text = "";
            // 
            // btnAdicionarAmigo
            // 
            this.btnAdicionarAmigo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAdicionarAmigo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAdicionarAmigo.FlatAppearance.BorderSize = 2;
            this.btnAdicionarAmigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnAdicionarAmigo.ForeColor = System.Drawing.Color.White;
            this.btnAdicionarAmigo.Location = new System.Drawing.Point(293, 18);
            this.btnAdicionarAmigo.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdicionarAmigo.Name = "btnAdicionarAmigo";
            this.btnAdicionarAmigo.Size = new System.Drawing.Size(144, 29);
            this.btnAdicionarAmigo.TabIndex = 10;
            this.btnAdicionarAmigo.Text = "Adicionar Amigos";
            this.btnAdicionarAmigo.UseVisualStyleBackColor = false;
            this.btnAdicionarAmigo.Click += new System.EventHandler(this.btnAdicionarAmigo_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel7.Controls.Add(this.label1);
            this.panel7.Controls.Add(this.pictureBox4);
            this.panel7.Location = new System.Drawing.Point(-2, -1);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1306, 33);
            this.panel7.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(40, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 29);
            this.label1.TabIndex = 24;
            this.label1.Text = "Perfil";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ProjBase1.Properties.Resources.logoSquirrel24;
            this.pictureBox4.Location = new System.Drawing.Point(12, 5);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(24, 24);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 23;
            this.pictureBox4.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel3.Location = new System.Drawing.Point(1027, 27);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(5, 715);
            this.panel3.TabIndex = 32;
            // 
            // ChatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(1280, 720);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panelAddFriend);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.flowLayoutPanelSolicitacoes);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.flowLayoutPanelAmigos);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.excluirAmigo);
            this.Controls.Add(this.pictureBoxFotoAmigo);
            this.Controls.Add(this.labelNomeAmigo);
            this.Controls.Add(this.flowLayoutPanelPostagens);
            this.Controls.Add(this.Perfil);
            this.Controls.Add(this.verChat);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "ChatForm";
            this.Text = "ChatForm";
            this.Load += new System.EventHandler(this.ChatForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFotoAmigo)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panelAddFriend.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttontEnviar;
        private System.Windows.Forms.Label labelNomeAmigo;
        private System.Windows.Forms.TextBox textBoxMensagem;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelPostagens;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button verChat;
        private System.Windows.Forms.Button Perfil;
        private System.Windows.Forms.PictureBox pictureBoxFotoAmigo;
        private System.Windows.Forms.Button excluirAmigo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btHome;
        private System.Windows.Forms.Button btMenu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btComunidade;
        private System.Windows.Forms.Button btSettings;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btAmigos;
        private System.Windows.Forms.Button btProfile;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelAmigos;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelSolicitacoes;
        private System.Windows.Forms.Panel panelAddFriend;
        private System.Windows.Forms.RichTextBox textBoxNomeAmigo;
        private System.Windows.Forms.Button btnAdicionarAmigo;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelMensagens;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel3;
    }
}