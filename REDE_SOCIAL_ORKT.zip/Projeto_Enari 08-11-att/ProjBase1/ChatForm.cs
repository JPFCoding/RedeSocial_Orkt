﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using static ProjBase1.Form4;
using static ProjBase1.Form3;
using System.Drawing;


namespace ProjBase1
{
    public partial class ChatForm : Form
    {
        private string nomeAmigo;

        public class Mensagem
        {
            public string De { get; set; }
            public string Para { get; set; }
            public string Texto { get; set; } 
            public DateTime DataEnvio { get; set; } 
        }

        public static class DadosChat
        {
            public static Dictionary<string, List<Mensagem>> Conversas = new Dictionary<string, List<Mensagem>>();
        }

        private List<Postagem> feedGeral;

        public ChatForm(string nome,Image foto, List<Postagem> feedGeral)
        {
            InitializeComponent();
            nomeAmigo = nome;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.feedGeral = feedGeral ?? new List<Postagem>(); // Atribuindo e evitando null
            labelNomeAmigo.Text = nomeAmigo;
            pictureBoxFotoAmigo.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxFotoAmigo.Image = foto;

            
            CarregarMensagens(DadosUsuario.UsuarioLogado.Nome, nomeAmigo);
            CarregarPostagensAmigo(); 
        }

        
        private void buttonEnviar_Click(object sender, EventArgs e)
        {
            string mensagem = textBoxMensagem.Text;

            if (!string.IsNullOrWhiteSpace(mensagem))
            {
                AdicionarMensagem(DadosUsuario.UsuarioLogado.Nome, mensagem); 
                EnviarMensagem(DadosUsuario.UsuarioLogado.Nome, nomeAmigo, mensagem); 
                textBoxMensagem.Clear(); 
            }
        }

        private void EnviarMensagem(string de, string para, string texto)
        {
            var mensagem = new Mensagem
            {
                De = de,
                Para = para,
                Texto = texto,
                DataEnvio = DateTime.Now
            };

            string chaveConversa = GerarChaveConversa(de, para);

            if (!DadosChat.Conversas.ContainsKey(chaveConversa))
            {
                DadosChat.Conversas[chaveConversa] = new List<Mensagem>();
            }

            DadosChat.Conversas[chaveConversa].Add(mensagem);
        }

        // Método para gerar a chave da conversa
        private string GerarChaveConversa(string usuario1, string usuario2)
        {
            return $"{Math.Min(usuario1.GetHashCode(), usuario2.GetHashCode())}-{Math.Max(usuario1.GetHashCode(), usuario2.GetHashCode())}";
        }

        // Método para carregar mensagens ao abrir o chat
        private void CarregarMensagens(string usuarioLogado, string amigo)
        {
            string chaveConversa = GerarChaveConversa(usuarioLogado, amigo);

            if (DadosChat.Conversas.ContainsKey(chaveConversa))
            {
                var mensagens = DadosChat.Conversas[chaveConversa];

                foreach (var mensagem in mensagens)
                {
                    AdicionarMensagem(mensagem.De, mensagem.Texto);
                }
            }
        }

        private void AdicionarMensagem(string remetente, string mensagem)
        {
            // Criação do painel da mensagem
            Panel messagePanel = new Panel
            {
                AutoSize = true,
                MaximumSize = new Size(flowLayoutPanelMensagens.Width - 20, 0),
                BorderStyle = BorderStyle.None,
                Padding = new Padding(5),
                Margin = new Padding(5)
            };

            // Criação do rótulo da mensagem
            Label lblMensagem = new Label
            {
                Text = mensagem,
                AutoSize = true,
                Font = new Font("Arial", 10, FontStyle.Regular),
                Padding = new Padding(5),
                MaximumSize = new Size(flowLayoutPanelMensagens.ClientSize.Width - 20, 0),
                AutoEllipsis = true,
                BorderStyle = BorderStyle.FixedSingle,
            };

            if (remetente == DadosUsuario.UsuarioLogado.Nome)
            {
                // Definir o estilo para a mensagem do remetente (alinhada à direita)
                lblMensagem.BackColor = Color.LightBlue;
                lblMensagem.TextAlign = ContentAlignment.MiddleLeft;

                // Alinha o painel à direita, independente do tamanho
                messagePanel.Anchor = AnchorStyles.Right;
                messagePanel.Controls.Add(lblMensagem);
                messagePanel.Margin = new Padding(flowLayoutPanelMensagens.Width - messagePanel.PreferredSize.Width - 25, 5, 5, 5);
            }
            else
            {
                // Definir o estilo para a mensagem recebida (alinhada à esquerda)
                lblMensagem.BackColor = Color.LightGray;
                lblMensagem.TextAlign = ContentAlignment.MiddleLeft;

                // Alinha o painel à esquerda
                messagePanel.Anchor = AnchorStyles.Left;
                messagePanel.Controls.Add(lblMensagem);
                messagePanel.Margin = new Padding(5, 5, flowLayoutPanelMensagens.Width - messagePanel.PreferredSize.Width - 25, 5);
            }

            // Adiciona o painel de mensagem ao flowLayoutPanel
            flowLayoutPanelMensagens.Controls.Add(messagePanel);
            flowLayoutPanelMensagens.ScrollControlIntoView(messagePanel);
        }






        private void CarregarPostagensAmigo()
        {
            flowLayoutPanelPostagens.Controls.Clear();

            var postagensDoAmigo = Form3.DadosGlobal1.FeedGeral
                .Where(p => p.Autor.Equals(nomeAmigo, StringComparison.OrdinalIgnoreCase))
                .ToList();

            foreach (var postagem in postagensDoAmigo)
            {
                // Cria o painel para cada postagem
                Panel postPanel = new Panel
                {
                    Size = new Size(flowLayoutPanelPostagens.Width - 40, 300),
                    BorderStyle = BorderStyle.None,
                    BackColor = Color.FromArgb(40, 40, 40),
                    Padding = new Padding(15),
                    Margin = new Padding(0, 10, 0, 10),
                    AutoScroll = true
                };
                postPanel.Region = new Region(new RectangleF(0, 0, postPanel.Width, postPanel.Height));

                // Exibe o autor
                Label autorLabel = new Label
                {
                    Text = postagem.Autor ?? "Autor desconhecido",
                    AutoSize = true,
                    Location = new Point(10, 10),
                    Font = new Font("Microsoft Sans Serif", 11, FontStyle.Italic),
                    ForeColor = Color.LightGray
                };
                postPanel.Controls.Add(autorLabel);

                // Texto do post
                Label lblPost = new Label
                {
                    Text = postagem.Post,
                    Location = new Point(10, 30),
                    MaximumSize = new Size(postPanel.Width - 20, 0),
                    Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold),
                    ForeColor = Color.White,
                    AutoSize = true
                };
                postPanel.Controls.Add(lblPost);

                // Imagem centralizada
                if (postagem.Imagem != null)
                {
                    PictureBox picImagem = new PictureBox
                    {
                        Image = postagem.Imagem,
                        SizeMode = PictureBoxSizeMode.Zoom,
                        Size = new Size(postPanel.Width - 40, 140),
                        Location = new Point((postPanel.Width - (postPanel.Width - 40)) / 2, lblPost.Bottom + 10),
                        BorderStyle = BorderStyle.FixedSingle,
                        BackColor = Color.LightGray
                    };
                    postPanel.Controls.Add(picImagem);
                }

                // Contador de Likes
                Label lblLikes = new Label
                {
                    Text = $"👍 Curtidas: {postagem.UsuariosQueCurtiram.Count}",
                    AutoSize = true,
                    Location = new Point(10, 210),
                    Font = new Font("Microsoft Sans Serif", 11, FontStyle.Bold),
                    ForeColor = Color.White,
                    BackColor = Color.FromArgb(30, 30, 30),
                    Padding = new Padding(5, 2, 5, 2)
                };
                postPanel.Controls.Add(lblLikes);

                // Painel de comentários
                if (postagem.Comentarios.Any())
                {
                    Panel commentsPanel = new Panel
                    {
                        Location = new Point(10, lblLikes.Bottom + 10),
                        Size = new Size(postPanel.Width - 30, 50),
                        BackColor = Color.FromArgb(50, 50, 50),
                        BorderStyle = BorderStyle.FixedSingle,
                        AutoScroll = true,
                        Padding = new Padding(5)
                    };

                    Label commentsLabel = new Label
                    {
                        Text = string.Join("\n", postagem.Comentarios),
                        AutoSize = true,
                        MaximumSize = new Size(commentsPanel.Width - 10, 0),
                        Font = new Font("Microsoft Sans Serif", 9),
                        ForeColor = Color.LightGray
                    };
                    commentsPanel.Controls.Add(commentsLabel);
                    postPanel.Controls.Add(commentsPanel);
                }

                // Adiciona o painel de postagem ao FlowLayoutPanel
                flowLayoutPanelPostagens.Controls.Add(postPanel);
            }
        }




        private void ChatForm_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            flowLayoutPanelPostagens.Visible = true;
            CarregarAmigos();
        }

        private void flowLayoutPanelPostagens_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void verChat_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            flowLayoutPanelPostagens.Visible = false;
        }

        private void Perfil_Click(object sender, EventArgs e)
        {
            flowLayoutPanelPostagens.Visible = true;
            panel1.Visible = false;
        }

        private void labelNomeAmigo_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var usuarioLogado = DadosUsuario.UsuarioLogado;

            // Remove o amigo da lista de amigos do usuário logado
            var amigoParaRemover = usuarioLogado.Amigos
                .FirstOrDefault(usuario => usuario.Nome.Equals(nomeAmigo, StringComparison.OrdinalIgnoreCase));

            if (amigoParaRemover != null)
            {
                usuarioLogado.Amigos.Remove(amigoParaRemover);
                RemoverAmizadeMutua(amigoParaRemover, usuarioLogado.Nome);

                MessageBox.Show($"{nomeAmigo} foi removido da sua lista de amigos.", "Amigo Removido", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();

                // Atualiza o painel de amigos chamando o Form3
                Form3 form3 = new Form3();
                form3.ShowDialog();
                Refresh();
            }
        }

        private void RemoverAmizadeMutua(Usuario amigo, string nomeUsuarioLogado)
        {
            // Remove o usuário logado da lista de amigos do outro perfil
            var amizadeMutua = amigo.Amigos
                .FirstOrDefault(a => a.Nome.Equals(nomeUsuarioLogado, StringComparison.OrdinalIgnoreCase));

            if (amizadeMutua != null)
            {
                amigo.Amigos.Remove(amizadeMutua);
            }
        }


        private void voltar_Click(object sender, EventArgs e)
        {
            this.Close();
            Form3 form3 = new Form3();
            form3.ShowDialog();
            
        }

        private void btHome_Click(object sender, EventArgs e)
        {
            Form3 form3 = Application.OpenForms.OfType<Form3>().FirstOrDefault();
            if (form3 != null)
            {
                form3.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Erro: O feed não foi encontrado.");
            }

        }

        private void btProfile_Click(object sender, EventArgs e)
        {
            this.Hide();

            using (Form4 form = new Form4())
            {
                form.ShowDialog();
            }

            this.Show();

            //AtualizarPosts();
            //AtualizarFeedGeral();
            if (DadosUsuario.UsuarioLogado.FotoPerfil != null)
            {
                pictureBox1.Image = DadosUsuario.UsuarioLogado.FotoPerfil;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void btComunidade_Click(object sender, EventArgs e)
        {
            Community community = new Community();
            community.Show();
            this.Close();
        }

        private void btAmigos_Click(object sender, EventArgs e)
        {
            panelAddFriend.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
            this.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            // Verifica se há um usuário logado antes de deslogar
            if (DadosUsuario.UsuarioLogado != null)
            {
                // Armazena o estado atual dos posts e imagens do usuário
                string nomeUsuario = DadosUsuario.UsuarioLogado.Nome;
                if (DadosUsuario.Usuarios.ContainsKey(nomeUsuario))
                {
                    DadosUsuario.Usuarios[nomeUsuario] = DadosUsuario.UsuarioLogado;
                }

                // Desassocia o usuário logado
                DadosUsuario.UsuarioLogado = null;
                flowLayoutPanelAmigos.Controls.Clear();

            }

            // Esconde a tela atual e abre a tela de login novamente
            this.Hide();
            Form1 form = new Form1();
            form.ShowDialog();
            this.Close();
        }

        private void btnAdicionarAmigo_Click(object sender, EventArgs e)
        {
            string nomeAmigo = textBoxNomeAmigo.Text.Trim();

            if (!string.IsNullOrEmpty(nomeAmigo))
            {
                if (DadosUsuario.Usuarios.TryGetValue(nomeAmigo, out var amigo))
                {
                    // Adiciona a solicitação na lista de pendentes do amigo
                    if (!amigo.SolicitacoesPendentes.Contains(DadosUsuario.UsuarioLogado.Nome))
                    {
                        amigo.SolicitacoesPendentes.Add(DadosUsuario.UsuarioLogado.Nome);
                        MessageBox.Show("Solicitação de amizade enviada!", "Sucesso", MessageBoxButtons.OK);
                        textBoxNomeAmigo.Clear();
                        panelAddFriend.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Você já enviou uma solicitação para esse usuário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Amigo não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o nome do amigo.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void ExibirAmigoNoPanel(string nome, Image foto)
        {
            Refresh();
            Button amigoButton = new Button
            {
                Size = new Size(100, 100),
                TextAlign = ContentAlignment.BottomCenter,
                TextImageRelation = TextImageRelation.ImageAboveText,
                BackColor = Color.White
            };

            if (foto != null)
            {
                Image imagemReduzida = RedimensionarImagem(foto, 70, 70);
                amigoButton.Image = imagemReduzida;
                amigoButton.ImageAlign = ContentAlignment.TopCenter;
                amigoButton.Text = nome;
            }
            else
            {
                amigoButton.Text = nome;
            }

            amigoButton.Click += (sender, e) =>
            {
                OpenChatForm(nome, foto);
                this.Close();
            };
            flowLayoutPanelAmigos.Controls.Add(amigoButton);
        }

        private Image RedimensionarImagem(Image img, int largura, int altura)
        {
            Bitmap bmp = new Bitmap(largura, altura);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.DrawImage(img, 0, 0, largura, altura);
            }
            return bmp;
        }

        private void OpenChatForm(string nomeAmigo, Image fotoAmigo)
        {
            ChatForm chatForm = new ChatForm(nomeAmigo, fotoAmigo, Form3.DadosGlobal1.FeedGeral);
            chatForm.Show();
        }



        private void CarregarAmigos()
        {
            Refresh();
            // Limpa os amigos exibidos anteriormente para evitar duplicações
            flowLayoutPanelAmigos.Controls.Clear();

            // Verifica se o usuário tem amigos
            if (DadosUsuario.UsuarioLogado.Amigos != null)
            {
                foreach (var amigo in DadosUsuario.UsuarioLogado.Amigos)
                {
                    // Verifica se a foto do amigo não é nula
                    if (amigo.FotoPerfil != null)
                    {
                        // Chame a função para exibir o amigo com foto
                        ExibirAmigoNoPanel(amigo.Nome, amigo.FotoPerfil);
                    }
                    else
                    {
                        // Chame a função para exibir o amigo sem foto
                        ExibirAmigoNoPanel(amigo.Nome, null); // Ou utilize uma imagem padrão
                    }
                }
            }
        }
    }
}

