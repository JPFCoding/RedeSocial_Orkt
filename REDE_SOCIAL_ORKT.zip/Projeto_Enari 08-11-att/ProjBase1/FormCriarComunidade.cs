﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ProjBase1.Community;
using static ProjBase1.Form4;

namespace ProjBase1
{
    public partial class FormCriarComunidade : Form
    {
        public Comunidade NovaComunidade { get; private set; }

        public FormCriarComunidade()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void FormCriarComunidade_Load(object sender, EventArgs e)
        {

        }

        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            string nome = textBoxNome.Text;
            string descricao = textBoxDescricao.Text;
            Image foto = pictureBoxFoto.Image;

            if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(descricao))
            {
                MessageBox.Show("Todos os campos devem ser preenchidos.");
                return;
            }

            // Criação da nova comunidade
            NovaComunidade = new Comunidade(nome, descricao, foto, DadosUsuario.UsuarioLogado.Nome);
            MessageBox.Show("Comunidade criada com sucesso!");
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnSelecionarFoto_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Filter = "Imagens (*.jpg;*.png)|*.jpg;*.png",
                Title = "Selecionar Foto da Comunidade"
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBoxFoto.SizeMode = PictureBoxSizeMode.Zoom;
                pictureBoxFoto.Image = Image.FromFile(ofd.FileName);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
