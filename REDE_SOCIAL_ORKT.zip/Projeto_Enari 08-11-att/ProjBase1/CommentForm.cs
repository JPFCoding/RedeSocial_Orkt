﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static ProjBase1.Form4;


namespace ProjBase1
{
    public partial class CommentForm : Form
    {
        public string CommentText { get; private set; }

        // Lista para armazenar comentários
        private List<string> comentarios;

        public CommentForm(List<string> comentarios)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Adicionar Comentário";
            this.comentarios = comentarios; // Inicializa a lista de comentários

            // Adicione um TextBox e um Button para o comentário
            TextBox textBoxComentario = new TextBox
            {
                Location = new System.Drawing.Point(10, 105),
                Width = 400,
                Font = new Font("Microsoft Sans Serif", 12)
            };
            this.Controls.Add(textBoxComentario);

            Button btnSalvar = new Button
            {
                Text = "Comentar",
                Location = new System.Drawing.Point(440, 103),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(255, 128, 0),
                Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold),
                Size = new Size(150,35)
            };
            this.Controls.Add(btnSalvar);

            btnSalvar.Click += (s, e) =>
            {
                CommentText = textBoxComentario.Text;

                // Adiciona o comentário à lista se não estiver vazio
                if (!string.IsNullOrWhiteSpace(CommentText))
                {
                    string comentarioComNome = $"{DadosUsuario.UsuarioLogado.Nome}: {CommentText}";
                    comentarios.Add(comentarioComNome);
                    MessageBox.Show("Comentário adicionado!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Por favor, insira um comentário válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            };


        }

        private void CommentForm_Load(object sender, EventArgs e)
        {
            // Lógica a ser executada quando o formulário carregar, se necessário
        }

        private void CommentForm_Load_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}