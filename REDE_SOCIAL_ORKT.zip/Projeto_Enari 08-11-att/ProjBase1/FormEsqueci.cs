﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjBase1
{
    public partial class FormEsqueci : Form
    {
        public FormEsqueci()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            novasenha.Visible = false; // Oculta campo nova senha inicialmente
            Confirmar.Visible = false; // Oculta botão confirmar inicialmente
        }

        private void verificar_Click(object sender, EventArgs e)
        {
            string email = textEmail.Text; // Obtém o e-mail inserido
            string resposta = richTextResposta.Text; // Obtém a resposta de segurança inserida

            // Busca o perfil pelo e-mail e verifica se a resposta de segurança coincide
            var usuarioRecuperacao = GetUserByEmailAndResposta(email, resposta);

            if (usuarioRecuperacao != null)
            {
                MessageBox.Show("Resposta correta. Insira uma nova senha.");
                novasenha.Visible = true; // Exibe campo para nova senha
                Confirmar.Visible = true; // Exibe botão de confirmar
            }
            else
            {
                MessageBox.Show("E-mail ou resposta incorretos. Tente novamente.");
            }
        }

        private Form2.Perfil GetUserByEmailAndResposta(string email, string resposta)
        {
            // Percorre a lista de perfis para encontrar o usuário com o e-mail e resposta corretos
            var atual = Form2.cabeca;
            while (atual != null)
            {
                // Supondo que Dados[2] é o e-mail e Dados[3] é a resposta de segurança
                if (atual.Dados[2] == email && atual.Dados[3] == resposta)
                {
                    return atual;
                }
                atual = atual.Proximo;
            }
            return null;
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            string novaSenha = novasenha.Text; // Obtém a nova senha digitada

            if (string.IsNullOrWhiteSpace(novaSenha))
            {
                MessageBox.Show("Por favor, insira uma nova senha.");
                return;
            }

            // Atualiza a senha do perfil do usuário com o e-mail registrado
            UpdateUserPassword(textEmail.Text, novaSenha);
            MessageBox.Show("Senha redefinida com sucesso!");

            // Oculta campos de redefinição após sucesso
            novasenha.Visible = false;
            Confirmar.Visible = false;
            Form1 form1 = new Form1();
            form1.ShowDialog();
            this.Close();
        }

        private void UpdateUserPassword(string email, string novaSenha)
        {
            var atual = Form2.cabeca;
            while (atual != null)
            {
                // Verifica o e-mail e atualiza a senha
                if (atual.Dados[2] == email)
                {
                    atual.Dados[1] = novaSenha; // Supondo que Dados[1] é o campo de senha
                    break;
                }
                atual = atual.Proximo;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void richTextResposta_TextChanged(object sender, EventArgs e)
        {
        }

        private void novasenha_TextChanged(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
