﻿using System;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjBase1
{
    public partial class Form2 : Form
    {
        public class Perfil
        {
            public string[] Dados;  // Array para armazenar nome, senha, e-mail e resposta
            public Perfil Proximo;

            public Perfil(string[] dados)
            {
                Dados = dados;
                Proximo = null;
            }
        }

        public static Perfil cabeca;

        Thread t1;
        Thread t2;

        public Form2()
        {
            InitializeComponent();
            this.Text = "Orkit";
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            string nome = textUser.Text;
            string senha = textPassword.Text;
            string email = textEmail.Text;
            string respostaSeguranca = textPergunta.Text;  

            // Verificação se nome, senha, e-mail e resposta estão preenchidos
            if (string.IsNullOrWhiteSpace(nome) /* || string.IsNullOrWhiteSpace(senha) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(respostaSeguranca)*/)
            {
                MessageBox.Show("Por favor, preencha todos os campos: Nome, Senha, E-mail e Resposta de Segurança.");
                return;
            }

            // Verificação de formato de e-mail usando regex
           /* if (!IsValidEmail(email))
            {
                MessageBox.Show("Por favor, insira um e-mail válido.");
                return;
            }
           */
            // Verifica se o usuário já está cadastrado pelo nome
            if (IsUserRegistered(nome))
            {
                MessageBox.Show("Usuário já cadastrado! Tente outro Nome.");
                return;
            }

            // Adiciona o usuário e exibe a mensagem de sucesso
            AddUser(nome, senha, email, respostaSeguranca);
            MessageBox.Show("Usuário cadastrado com sucesso!");

            // Fecha o formulário atual e abre a nova janela
            this.Close();
            t2 = new Thread(OpenW);
            t2.SetApartmentState(ApartmentState.STA);
            t2.Start();
        }

        private bool IsValidEmail(string email)
        {
            // Expressão regular para validar e-mails
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, emailPattern);
        }

        private void btAccess_Click(object sender, EventArgs e)
        {
            this.Close();
            t1 = new Thread(OpenW);
            t1.SetApartmentState(ApartmentState.STA);
            t1.Start();
        }

        private void OpenW()
        {
            Application.Run(new Form1());
        }

        private void AddUser(string nome, string senha, string email, string respostaSeguranca)
        {
            // Inclui o nome, senha, e-mail e resposta de segurança no array Dados
            Perfil novoPerfil = new Perfil(new string[] { nome, senha, email, respostaSeguranca });
            if (cabeca == null)
            {
                cabeca = novoPerfil;
            }
            else
            {
                Perfil atual = cabeca;
                while (atual.Proximo != null)
                {
                    atual = atual.Proximo;
                }
                atual.Proximo = novoPerfil;
            }
        }

        private bool IsUserRegistered(string nome)
        {
            Perfil atual = cabeca;
            while (atual != null)
            {
                if (atual.Dados[0] == nome)  // Verifica se o nome já está registrado
                {
                    return true;
                }
                atual = atual.Proximo;
            }
            return false;
        }

        public bool VerificaRespostaSeguranca(string nome, string resposta)
        {
            Perfil atual = cabeca;
            while (atual != null)
            {
                if (atual.Dados[0] == nome)
                {
                    return atual.Dados[3] == resposta; // Verifica se a resposta coincide com a registrada
                }
                atual = atual.Proximo;
            }
            return false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Opcional: você pode adicionar alguma lógica quando o texto da pergunta de segurança muda
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
