﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using static ProjBase1.Form3;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace ProjBase1
{
    public partial class Form4 : Form
    {
        private OpenFileDialog ofd1;

        public Form4()
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.Form4_Load);
            ofd1 = new OpenFileDialog();
            this.StartPosition = FormStartPosition.CenterScreen;
            toolTip1.SetToolTip(pictureBox1, "Clique para trocar a foto de perfil");
            pictureBox1.MouseEnter += PictureBox1_MouseEnter;
            pictureBox1.MouseLeave += PictureBox1_MouseLeave;
            pictureBox1.Paint += PictureBox1_Paint;
            pictureBox1.Invalidate();

        }

        public class Usuario
        {
            public string Nome { get; set; }
            public string Senha { get; set; }
            public Image FotoPerfil { get; set; }
            public List<string> Posts { get; set; } = new List<string>();
            public List<Image> Imagens { get; set; } = new List<Image>();
            public List<Usuario> Amigos { get; set; } = new List<Usuario>();
            public List<string> SolicitacoesPendentes { get; set; } = new List<string>();


        }



        public static class DadosGlobal
        {
            public static List<(string Post, Image Imagem)> FeedGeral { get; set; } = new List<(string, Image)>();
        }

        public static class DadosUsuario
        {
            public static Dictionary<string, Usuario> Usuarios = new Dictionary<string, Usuario>();
            public static Usuario UsuarioLogado { get; set; }

            public static void AdicionarAmigo(string nomeAmigo)
            {
                // Verifica se o amigo existe na lista de usuários
                if (Usuarios.ContainsKey(nomeAmigo))
                {
                    var amigo = Usuarios[nomeAmigo];

                    // Adiciona o amigo à lista de amigos do usuário logado, se ainda não for amigo
                    if (!UsuarioLogado.Amigos.Contains(amigo))
                    {
                        UsuarioLogado.Amigos.Add(amigo);
                        amigo.Amigos.Add(UsuarioLogado); // Torna a amizade mútua

                        MessageBox.Show($"{nomeAmigo} agora é seu amigo!");
                    }
                    else
                    {
                        MessageBox.Show("Esse usuário já é seu amigo.");
                    }
                }
                else
                {
                    MessageBox.Show("Usuário não encontrado.");
                }
            }

        }



        private void Form4_Load(object sender, EventArgs e)
        {
            Refresh();
            CarregarAmigos();
            if (DadosUsuario.UsuarioLogado != null)
            {
                nomeUsuario.Text = DadosUsuario.UsuarioLogado.Nome;

                if (DadosUsuario.UsuarioLogado.FotoPerfil != null)
                {
                    pictureBox1.Image = DadosUsuario.UsuarioLogado.FotoPerfil;
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }

                AtualizarPosts();
            }
            else
            {
                nomeUsuario.Text = "Nenhum usuário logado";
            }
            this.StartPosition = FormStartPosition.CenterScreen;
            toolTip1.SetToolTip(pictureBox1, "Clique para trocar a foto de perfil");
            pictureBox1.MouseEnter += PictureBox1_MouseEnter;
            pictureBox1.MouseLeave += PictureBox1_MouseLeave;
            pictureBox1.Paint += PictureBox1_Paint;

        }



        private void LimparDadosUsuario()
        {
            DadosUsuario.UsuarioLogado.Posts.Clear();
            DadosUsuario.UsuarioLogado.Imagens.Clear();
        }

        private void AtualizarPosts()
        {
            PostText.Controls.Clear();
            int yPosition = 10;
            int postPanelHeight = 300; // Altura ajustada para acomodar imagem, likes e comentários

            var postsUsuario = DadosUsuario.UsuarioLogado.Posts
                .Select((textoPost, index) => new
                {
                    Texto = textoPost,
                    Imagem = DadosUsuario.UsuarioLogado.Imagens[index],
                    PostagemCorrespondente = DadosGlobal1.FeedGeral.FirstOrDefault(p => p.Post == textoPost)
                })
                .Reverse()
                .ToList();

            foreach (var postItem in postsUsuario)
            {
                var post = postItem.PostagemCorrespondente;

                Panel postPanel = new Panel
                {
                    Size = new Size(PostText.Width - 40, postPanelHeight),
                    Location = new Point(20, yPosition),
                    BorderStyle = BorderStyle.None,
                    BackColor = Color.FromArgb(40, 40, 40),
                    Padding = new Padding(15)
                };
                postPanel.Region = new Region(new RectangleF(0, 0, postPanel.Width, postPanel.Height));

                // Autor do post
                Label autorLabel = new Label
                {
                    Text = post?.Autor ?? "Autor desconhecido",
                    AutoSize = true,
                    Location = new Point(10, 10),
                    Font = new Font("Microsoft Sans Serif", 11, FontStyle.Italic),
                    ForeColor = Color.LightGray
                };
                postPanel.Controls.Add(autorLabel);

                // Texto do post
                Label postLabel = new Label
                {
                    Text = postItem.Texto,
                    Location = new Point(10, 30),
                    MaximumSize = new Size(postPanel.Width - 20, 0),
                    Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold),
                    ForeColor = Color.White,
                    AutoSize = true
                };
                postPanel.Controls.Add(postLabel);

                // Imagem centralizada e aumentada
                PictureBox postImage = new PictureBox
                {
                    Image = postItem.Imagem,
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Size = new Size(postPanel.Width - 40, 140),
                    Location = new Point((postPanel.Width - (postPanel.Width - 40)) / 2, 60),
                    BorderStyle = BorderStyle.FixedSingle
                };
                postPanel.Controls.Add(postImage);

                // Contador de Likes entre a imagem e os comentários
                Label likeCountLabel = new Label
                {
                    Text = post != null ? $"👍{post.UsuariosQueCurtiram.Count} Curtidas" : "0 Curtidas",
                    AutoSize = true,
                    Location = new Point(10, 210), // Posiciona o contador logo abaixo da imagem
                    Font = new Font("Microsoft Sans Serif", 11, FontStyle.Bold),
                    ForeColor = Color.White,
                    BackColor = Color.FromArgb(30, 30, 30),
                    Padding = new Padding(5, 2, 5, 2)
                };
                postPanel.Controls.Add(likeCountLabel);

                // Painel de comentários reposicionado
                if (post != null && post.Comentarios.Any())
                {
                    Panel commentsPanel = new Panel
                    {
                        Location = new Point(10, 240), // Abaixo do contador de likes
                        Size = new Size(postPanel.Width - 30, 50),
                        BackColor = Color.FromArgb(50, 50, 50),
                        BorderStyle = BorderStyle.FixedSingle,
                        AutoScroll = true,
                        Padding = new Padding(5)
                    };

                    Label commentsLabel = new Label
                    {
                        Text = string.Join("\n", post.Comentarios),
                        AutoSize = true,
                        MaximumSize = new Size(commentsPanel.Width - 10, 0),
                        Font = new Font("Microsoft Sans Serif", 9),
                        ForeColor = Color.LightGray
                    };
                    commentsPanel.Controls.Add(commentsLabel);
                    postPanel.Controls.Add(commentsPanel);
                }

                PostText.Controls.Add(postPanel);
                yPosition += postPanelHeight + 10;
            }
        }




        private void new_post_Click(object sender, EventArgs e)
        {
            using (Form5 form = new Form5())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    AtualizarPosts();
                }
            }
        }

        private void nomeUsuario_TextChanged(object sender, EventArgs e)
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            ofd1.Multiselect = false;
            ofd1.Title = "Selecionar Imagem";
            ofd1.Filter = "Imagens (*.BMP;*.JPG;*.GIF;*.PNG;*.TIFF)|*.BMP;*.JPG;*.GIF;*.PNG;*.TIFF|" +
                          "Todos os arquivos (*.*)|*.*";
            ofd1.CheckFileExists = true;
            ofd1.CheckPathExists = true;
            ofd1.FilterIndex = 1;

            try
            {
                if (ofd1.ShowDialog() == DialogResult.OK)
                {
                    if (pictureBox1 != null && DadosUsuario.UsuarioLogado != null)
                    {
                        Image imagemSelecionada = Image.FromFile(ofd1.FileName);
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        pictureBox1.Image = imagemSelecionada;

                        DadosUsuario.UsuarioLogado.FotoPerfil = imagemSelecionada;


                        MessageBox.Show("Foto de perfil atualizada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Controle PictureBox ou usuário logado não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar a imagem: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PictureBox1_MouseEnter(object sender, EventArgs e)
        {
            // Mudar a cor de fundo ao passar o mouse
            pictureBox1.BackColor = Color.Gray;  // Alterar a cor de fundo
            mouseOverPictureBox = true;
            pictureBox1.Invalidate();  // Força o controle a ser repintado
        }

        private void PictureBox1_MouseLeave(object sender, EventArgs e)
        {
            // Reverter a cor de fundo ao sair o mouse
            pictureBox1.BackColor = Color.Transparent;  // Volta a cor original
            mouseOverPictureBox = false;
            pictureBox1.Invalidate();  // Força o controle a ser repintado
        }


        private void PictureBox1_Paint(object sender, PaintEventArgs e)
        {
            if (mouseOverPictureBox)
            {
                using (Font font = new Font("Arial", 10, FontStyle.Bold))
                using (Brush brush = new SolidBrush(Color.White))
                using (StringFormat format = new StringFormat
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                })
                {
                    // Certifique-se de que o método está sendo chamado
                    e.Graphics.DrawString("Clique para trocar a foto de perfil", font, brush, pictureBox1.ClientRectangle, format);
                }
            }
        }


        private bool mouseOverPictureBox = false;

        private void home_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void ExibirAmigoNoPanel(string nome, Image foto)
        {
            flowLayoutPanelAmigos.Controls.Clear();
            Refresh();
            Button amigoButton = new Button
            {
                Size = new Size(100, 100),
                TextAlign = ContentAlignment.BottomCenter,
                TextImageRelation = TextImageRelation.ImageAboveText,
                BackColor = Color.White

            };

            if (foto != null)
            {
                Image imagemReduzida = RedimensionarImagem(foto, 70, 70);
                amigoButton.Image = imagemReduzida;
                amigoButton.ImageAlign = ContentAlignment.TopCenter;
                amigoButton.Text = nome;
            }
            else
            {
                amigoButton.Text = nome;
            }

            amigoButton.Click += (sender, e) =>
            {
                OpenChatForm(nome, foto);
                this.Hide();
            };
            flowLayoutPanelAmigos.Controls.Add(amigoButton);
        }

        private Image RedimensionarImagem(Image img, int largura, int altura)
        {
            Bitmap bmp = new Bitmap(largura, altura);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.DrawImage(img, 0, 0, largura, altura);
            }
            return bmp;
        }

        private void OpenChatForm(string nomeAmigo, Image fotoAmigo)
        {
            ChatForm chatForm = new ChatForm(nomeAmigo, fotoAmigo, Form3.DadosGlobal1.FeedGeral);
            chatForm.ShowDialog();
        }



        private void CarregarAmigos()
        {
            Refresh();
            // Limpa os amigos exibidos anteriormente para evitar duplicações
            flowLayoutPanelAmigos.Controls.Clear();

            // Verifica se o usuário tem amigos
            if (DadosUsuario.UsuarioLogado.Amigos != null)
            {
                foreach (var amigo in DadosUsuario.UsuarioLogado.Amigos)
                {
                    // Verifica se a foto do amigo não é nula
                    if (amigo.FotoPerfil != null)
                    {
                        // Chame a função para exibir o amigo com foto
                        ExibirAmigoNoPanel(amigo.Nome, amigo.FotoPerfil);
                    }
                    else
                    {
                        // Chame a função para exibir o amigo sem foto
                        ExibirAmigoNoPanel(amigo.Nome, null); // Ou utilize uma imagem padrão
                    }
                }
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void btHome_Click(object sender, EventArgs e)
        {
            this.Close();
            Form3 f3 = new Form3();
            f3.Show();

            /*
            Form3 form3 = Application.OpenForms.OfType<Form3>().FirstOrDefault();
            if (form3 != null)
            {
                form3.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Erro: O feed não foi encontrado.");
            }
            */

        }

        private void btProfile_Click(object sender, EventArgs e)
        {

        }

        private void btComunidade_Click(object sender, EventArgs e)
        {
            this.Close();
            Community community = new Community();
            community.Show();
            
        }

        private void btAmigos_Click(object sender, EventArgs e)
        {
            panel4.Visible = true;
        }

        private void btnAdicionarAmigo_Click(object sender, EventArgs e)
        {
            string nomeAmigo = textBoxNomeAmigo.Text.Trim();

            if (!string.IsNullOrEmpty(nomeAmigo))
            {
                if (DadosUsuario.Usuarios.TryGetValue(nomeAmigo, out var amigo))
                {
                    // Adiciona a solicitação na lista de pendentes do amigo
                    if (!amigo.SolicitacoesPendentes.Contains(DadosUsuario.UsuarioLogado.Nome))
                    {
                        amigo.SolicitacoesPendentes.Add(DadosUsuario.UsuarioLogado.Nome);
                        MessageBox.Show("Solicitação de amizade enviada!", "Sucesso", MessageBoxButtons.OK);
                        textBoxNomeAmigo.Clear();
                        panel4.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Você já enviou uma solicitação para esse usuário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Amigo não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o nome do amigo.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Verifica se há um usuário logado antes de deslogar
            if (DadosUsuario.UsuarioLogado != null)
            {
                // Armazena o estado atual dos posts e imagens do usuário
                string nomeUsuario = DadosUsuario.UsuarioLogado.Nome;
                if (DadosUsuario.Usuarios.ContainsKey(nomeUsuario))
                {
                    DadosUsuario.Usuarios[nomeUsuario] = DadosUsuario.UsuarioLogado;
                }

                // Desassocia o usuário logado
                DadosUsuario.UsuarioLogado = null;
                flowLayoutPanelAmigos.Controls.Clear();

            }

            Form1 form = new Form1();
            form.ShowDialog();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form6 form6 = new Form6();
            form6.Show();
        }

        private void flowLayoutPanelAmigos_Paint(object sender, PaintEventArgs e)
        {

        }
    }


}
