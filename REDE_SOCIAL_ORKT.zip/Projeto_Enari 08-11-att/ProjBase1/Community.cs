﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using static ProjBase1.Community;
using static ProjBase1.Form4;

namespace ProjBase1
{
    

    public partial class Community : Form
    {
        public static class ComunidadeRepository
        {
            public static List<Comunidade> TodasComunidades { get; set; } = new List<Comunidade>();
        }
        public class Comunidade
        {
            public string Nome { get; set; }
            public string Descricao { get; set; }
            public Image Foto { get; set; }
            public string Dono { get; set; }
            public List<string> Membros { get; set; } = new List<string>();
            public List<string> Posts { get; set; } = new List<string>();

            public Comunidade(string nome, string descricao, Image foto, string dono)
            {
                Nome = nome;
                Descricao = descricao;
                Foto = foto;
                Dono = dono;
                Membros.Add(dono); // O dono já é um membro
            }
        }

        public Community()
        {
            InitializeComponent();
            ExibirComunidades(); // Carregar as comunidades ao inicializar
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        private void btComunidade_Click(object sender, EventArgs e)
        {
            FormCriarComunidade formCriar = new FormCriarComunidade();
            if (formCriar.ShowDialog() == DialogResult.OK)
            {
                ComunidadeRepository.TodasComunidades.Add(formCriar.NovaComunidade);
                ExibirComunidades();
            }
        }

        private void btSearch_Click(object sender, EventArgs e)
        {
            using (InputForm inputForm = new InputForm(""))
            {
                if (inputForm.ShowDialog() == DialogResult.OK)
                {
                    string nomeComunidade = inputForm.Valor;

                    // Verifique se a comunidade existe na lista de comunidades
                    Comunidade comunidadeEncontrada = ComunidadeRepository.TodasComunidades
                        .FirstOrDefault(c => c.Nome.Equals(nomeComunidade, StringComparison.OrdinalIgnoreCase));

                    if (comunidadeEncontrada != null)
                    {
                        DialogResult result = MessageBox.Show($"Deseja entrar na comunidade {comunidadeEncontrada.Nome}?", "Confirmar", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            comunidadeEncontrada.Membros.Add(DadosUsuario.UsuarioLogado.Nome);
                            MessageBox.Show("Você entrou na comunidade!");
                            ExibirComunidades();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Comunidade não encontrada.");
                    }
                }
            }
        }

        private void btSuasComunidades_Click(object sender, EventArgs e)
        {
            ExibirComunidadesDoUsuario();
        }

        private void ExibirComunidades()
        {
            flowLayoutPanel1.Controls.Clear();

            foreach (var comunidade in ComunidadeRepository.TodasComunidades)
            {
                // Adiciona as comunidades que o usuário é membro ou que ele criou
                if (comunidade.Membros.Contains(DadosUsuario.UsuarioLogado.Nome) || comunidade.Dono == DadosUsuario.UsuarioLogado.Nome)
                {
                    // Criando o painel que conterá a imagem e o nome
                    Panel panelComunidade = new Panel
                    {
                        Size = new Size(150, 130),
                        BorderStyle = BorderStyle.FixedSingle,
                        Margin = new Padding(5),
                        BackColor = Color.Gray
                    };

                    // Criando o PictureBox para exibir a imagem redimensionada
                    PictureBox picComunidade = new PictureBox
                    {
                        Image = comunidade.Foto,
                        SizeMode = PictureBoxSizeMode.Zoom, // Redimensiona a imagem para caber no PictureBox
                        Size = new Size(130, 90),
                        Location = new Point(10, 10),
                        Cursor = Cursors.Hand, // Aponta que é um botão
                        BorderStyle = BorderStyle.FixedSingle
                    };

                    // Evento de clique na PictureBox
                    picComunidade.Click += (s, e) =>
                    {
                        
                        FormComunidade formComunidade = new FormComunidade(comunidade);
                        formComunidade.ShowDialog();
                    };

                    // Criando o Label para exibir o nome da comunidade
                    Label lblNomeComunidade = new Label
                    {
                        Text = comunidade.Nome,
                        TextAlign = ContentAlignment.MiddleCenter,
                        Location = new Point(10, 105),
                        Size = new Size(130, 20),
                        ForeColor = Color.White,
                        Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold),
                        AutoSize = false
                    };

                    // Adicionando os controles ao painel
                    panelComunidade.Controls.Add(picComunidade);
                    panelComunidade.Controls.Add(lblNomeComunidade);

                    // Adicionando o painel ao flowLayoutPanel
                    flowLayoutPanel1.Controls.Add(panelComunidade);
                }
            }
        }

        private void ExibirComunidadesDoUsuario()
        {
            flowLayoutPanel1.Controls.Clear();

            var comunidadesUsuario = ComunidadeRepository.TodasComunidades
                .Where(c => c.Dono == DadosUsuario.UsuarioLogado.Nome).ToList();

            foreach (var comunidade in comunidadesUsuario)
            {
                // Criando o painel que conterá a imagem e o nome
                Panel panelComunidade = new Panel
                {
                    Size = new Size(150, 130),
                    BorderStyle = BorderStyle.FixedSingle,
                    Margin = new Padding(5),
                    BackColor = Color.Gray
                };

                // Criando o PictureBox para exibir a imagem redimensionada
                PictureBox picComunidade = new PictureBox
                {
                    Image = comunidade.Foto,
                    SizeMode = PictureBoxSizeMode.Zoom, // Redimensiona a imagem para caber no PictureBox
                    Size = new Size(130, 90),
                    Location = new Point(10, 10),
                    Cursor = Cursors.Hand, // Aponta que é um botão
                    BorderStyle = BorderStyle.FixedSingle
                };

                // Evento de clique na PictureBox
                picComunidade.Click += (s, e) =>
                {
                    
                    FormComunidade formComunidade = new FormComunidade(comunidade);
                    formComunidade.ShowDialog();
                };

                // Criando o Label para exibir o nome da comunidade
                Label lblNomeComunidade = new Label
                {
                    Text = comunidade.Nome,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Location = new Point(10, 105),
                    Size = new Size(130, 20),
                    ForeColor = Color.White,
                    Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold),
                    AutoSize = false
                };

                // Adicionando os controles ao painel
                panelComunidade.Controls.Add(picComunidade);
                panelComunidade.Controls.Add(lblNomeComunidade);

                // Adicionando o painel ao flowLayoutPanel
                flowLayoutPanel1.Controls.Add(panelComunidade);
            }
        }

        private void Community_Load(object sender, EventArgs e)
        {
            CarregarAmigos();
            Refresh();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void btHome_Click(object sender, EventArgs e)
        {
            this.Close();
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Verifica se há um usuário logado antes de deslogar
            if (DadosUsuario.UsuarioLogado != null)
            {
                // Armazena o estado atual dos posts e imagens do usuário
                string nomeUsuario = DadosUsuario.UsuarioLogado.Nome;
                if (DadosUsuario.Usuarios.ContainsKey(nomeUsuario))
                {
                    DadosUsuario.Usuarios[nomeUsuario] = DadosUsuario.UsuarioLogado;
                }

                // Desassocia o usuário logado
                DadosUsuario.UsuarioLogado = null;
                

            }

            // Esconde a tela atual e abre a tela de login novamente
            this.Hide();
            Form1 form = new Form1();
            form.ShowDialog();
            this.Hide();
        }

        private void btProfile_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 f4 = new Form4();
            f4.Show();

            
            if (DadosUsuario.UsuarioLogado.FotoPerfil != null)
            {
                pictureBox1.Image = DadosUsuario.UsuarioLogado.FotoPerfil;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void ExibirAmigoNoPanel(string nome, Image foto)
        {
            Refresh();
            Button amigoButton = new Button
            {
                Size = new Size(100, 100),
                TextAlign = ContentAlignment.BottomCenter,
                TextImageRelation = TextImageRelation.ImageAboveText,
                BackColor = Color.White
            };

            if (foto != null)
            {
                Image imagemReduzida = RedimensionarImagem(foto, 70, 70);
                amigoButton.Image = imagemReduzida;
                amigoButton.ImageAlign = ContentAlignment.TopCenter;
                amigoButton.Text = nome;
            }
            else
            {
                amigoButton.Text = nome;
            }

            amigoButton.Click += (sender, e) =>
            {

                OpenChatForm(nome, foto);
                this.Close();
            };
            flowLayoutPanelAmigos.Controls.Add(amigoButton);
        }

        private Image RedimensionarImagem(Image img, int largura, int altura)
        {
            Bitmap bmp = new Bitmap(largura, altura);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.DrawImage(img, 0, 0, largura, altura);
            }
            return bmp;
        }

        private void OpenChatForm(string nomeAmigo, Image fotoAmigo)
        {

            ChatForm chatForm = new ChatForm(nomeAmigo, fotoAmigo, Form3.DadosGlobal1.FeedGeral);
            chatForm.Show();
        }

        

        private void CarregarAmigos()
        {
            Refresh();
            // Limpa os amigos exibidos anteriormente para evitar duplicações
            flowLayoutPanelAmigos.Controls.Clear();

            // Verifica se o usuário tem amigos
            if (DadosUsuario.UsuarioLogado.Amigos != null)
            {
                foreach (var amigo in DadosUsuario.UsuarioLogado.Amigos)
                {
                    // Verifica se a foto do amigo não é nula
                    if (amigo.FotoPerfil != null)
                    {
                        // Chame a função para exibir o amigo com foto
                        ExibirAmigoNoPanel(amigo.Nome, amigo.FotoPerfil);
                    }
                    else
                    {
                        // Chame a função para exibir o amigo sem foto
                        ExibirAmigoNoPanel(amigo.Nome, null); // Ou utilize uma imagem padrão
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Form6 f6 = new Form6();
            f6.Show();
        }

        private void btAmigos_Click(object sender, EventArgs e)
        {
            panelAddFriend.Visible = true;
        }

        private void btnAdicionarAmigo_Click(object sender, EventArgs e)
        {
            string nomeAmigo = textBoxNomeAmigo.Text.Trim();

            if (!string.IsNullOrEmpty(nomeAmigo))
            {
                if (DadosUsuario.Usuarios.TryGetValue(nomeAmigo, out var amigo))
                {
                    // Adiciona a solicitação na lista de pendentes do amigo
                    if (!amigo.SolicitacoesPendentes.Contains(DadosUsuario.UsuarioLogado.Nome))
                    {
                        amigo.SolicitacoesPendentes.Add(DadosUsuario.UsuarioLogado.Nome);
                        MessageBox.Show("Solicitação de amizade enviada!", "Sucesso", MessageBoxButtons.OK);
                        textBoxNomeAmigo.Clear();
                        panelAddFriend.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Você já enviou uma solicitação para esse usuário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Amigo não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o nome do amigo.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ExibirComunidades();
        }
    }
}
