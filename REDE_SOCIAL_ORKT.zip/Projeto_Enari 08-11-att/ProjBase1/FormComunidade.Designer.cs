﻿namespace ProjBase1
{
    partial class FormComunidade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelNome = new System.Windows.Forms.Label();
            this.labelDescricao = new System.Windows.Forms.Label();
            this.listBoxPosts = new System.Windows.Forms.ListBox();
            this.textBoxPost = new System.Windows.Forms.TextBox();
            this.panelPostar = new System.Windows.Forms.Panel();
            this.btnPostar = new System.Windows.Forms.Button();
            this.pictureBoxFoto = new System.Windows.Forms.PictureBox();
            this.apagarComunidade = new System.Windows.Forms.Button();
            this.sairComunidade = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panelPostar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFoto)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelNome.ForeColor = System.Drawing.SystemColors.Window;
            this.labelNome.Location = new System.Drawing.Point(45, 52);
            this.labelNome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(51, 20);
            this.labelNome.TabIndex = 0;
            this.labelNome.Text = "Nome";
            // 
            // labelDescricao
            // 
            this.labelDescricao.AutoSize = true;
            this.labelDescricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelDescricao.ForeColor = System.Drawing.SystemColors.Window;
            this.labelDescricao.Location = new System.Drawing.Point(45, 117);
            this.labelDescricao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelDescricao.Name = "labelDescricao";
            this.labelDescricao.Size = new System.Drawing.Size(80, 20);
            this.labelDescricao.TabIndex = 1;
            this.labelDescricao.Text = "Descrição";
            // 
            // listBoxPosts
            // 
            this.listBoxPosts.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.listBoxPosts.FormattingEnabled = true;
            this.listBoxPosts.ItemHeight = 20;
            this.listBoxPosts.Location = new System.Drawing.Point(440, 81);
            this.listBoxPosts.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxPosts.Name = "listBoxPosts";
            this.listBoxPosts.Size = new System.Drawing.Size(269, 284);
            this.listBoxPosts.TabIndex = 3;
            // 
            // textBoxPost
            // 
            this.textBoxPost.Location = new System.Drawing.Point(4, 35);
            this.textBoxPost.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPost.Name = "textBoxPost";
            this.textBoxPost.Size = new System.Drawing.Size(232, 20);
            this.textBoxPost.TabIndex = 4;
            // 
            // panelPostar
            // 
            this.panelPostar.Controls.Add(this.btnPostar);
            this.panelPostar.Controls.Add(this.textBoxPost);
            this.panelPostar.Location = new System.Drawing.Point(47, 246);
            this.panelPostar.Margin = new System.Windows.Forms.Padding(2);
            this.panelPostar.Name = "panelPostar";
            this.panelPostar.Size = new System.Drawing.Size(252, 150);
            this.panelPostar.TabIndex = 5;
            // 
            // btnPostar
            // 
            this.btnPostar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnPostar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPostar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnPostar.ForeColor = System.Drawing.SystemColors.Window;
            this.btnPostar.Location = new System.Drawing.Point(4, 79);
            this.btnPostar.Margin = new System.Windows.Forms.Padding(2);
            this.btnPostar.Name = "btnPostar";
            this.btnPostar.Size = new System.Drawing.Size(103, 27);
            this.btnPostar.TabIndex = 6;
            this.btnPostar.Text = "Postar";
            this.btnPostar.UseVisualStyleBackColor = false;
            this.btnPostar.Click += new System.EventHandler(this.btnPostar_Click_1);
            // 
            // pictureBoxFoto
            // 
            this.pictureBoxFoto.Location = new System.Drawing.Point(181, 47);
            this.pictureBoxFoto.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBoxFoto.Name = "pictureBoxFoto";
            this.pictureBoxFoto.Size = new System.Drawing.Size(102, 102);
            this.pictureBoxFoto.TabIndex = 2;
            this.pictureBoxFoto.TabStop = false;
            this.pictureBoxFoto.Click += new System.EventHandler(this.pictureBoxFoto_Click);
            // 
            // apagarComunidade
            // 
            this.apagarComunidade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.apagarComunidade.Cursor = System.Windows.Forms.Cursors.Hand;
            this.apagarComunidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.apagarComunidade.ForeColor = System.Drawing.SystemColors.Window;
            this.apagarComunidade.Location = new System.Drawing.Point(49, 214);
            this.apagarComunidade.Margin = new System.Windows.Forms.Padding(2);
            this.apagarComunidade.Name = "apagarComunidade";
            this.apagarComunidade.Size = new System.Drawing.Size(180, 28);
            this.apagarComunidade.TabIndex = 7;
            this.apagarComunidade.Text = "Apagar Comunidade";
            this.apagarComunidade.UseVisualStyleBackColor = false;
            this.apagarComunidade.Click += new System.EventHandler(this.apagarComunidade_Click);
            // 
            // sairComunidade
            // 
            this.sairComunidade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sairComunidade.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sairComunidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.sairComunidade.ForeColor = System.Drawing.SystemColors.Window;
            this.sairComunidade.Location = new System.Drawing.Point(49, 181);
            this.sairComunidade.Margin = new System.Windows.Forms.Padding(2);
            this.sairComunidade.Name = "sairComunidade";
            this.sairComunidade.Size = new System.Drawing.Size(180, 29);
            this.sairComunidade.TabIndex = 8;
            this.sairComunidade.Text = "Sair da Comunidade";
            this.sairComunidade.UseVisualStyleBackColor = false;
            this.sairComunidade.Click += new System.EventHandler(this.sairComunidade_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(751, 30);
            this.panel2.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(37, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(304, 29);
            this.label2.TabIndex = 12;
            this.label2.Text = "Postagens da Comunidade";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ProjBase1.Properties.Resources.logoSquirrel24;
            this.pictureBox4.Location = new System.Drawing.Point(10, 3);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(24, 24);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Image = global::ProjBase1.Properties.Resources.icons8_close_28;
            this.button3.Location = new System.Drawing.Point(1243, -1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(40, 30);
            this.button3.TabIndex = 0;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(318, 392);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 27);
            this.button1.TabIndex = 20;
            this.button1.Text = "Voltar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // FormComunidade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(750, 430);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.sairComunidade);
            this.Controls.Add(this.apagarComunidade);
            this.Controls.Add(this.panelPostar);
            this.Controls.Add(this.listBoxPosts);
            this.Controls.Add(this.pictureBoxFoto);
            this.Controls.Add(this.labelDescricao);
            this.Controls.Add(this.labelNome);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormComunidade";
            this.Text = "FormComunidade";
            this.Load += new System.EventHandler(this.FormComunidade_Load);
            this.panelPostar.ResumeLayout(false);
            this.panelPostar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFoto)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.Label labelDescricao;
        private System.Windows.Forms.PictureBox pictureBoxFoto;
        private System.Windows.Forms.ListBox listBoxPosts;
        private System.Windows.Forms.TextBox textBoxPost;
        private System.Windows.Forms.Panel panelPostar;
        private System.Windows.Forms.Button btnPostar;
        private System.Windows.Forms.Button apagarComunidade;
        private System.Windows.Forms.Button sairComunidade;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
    }
}