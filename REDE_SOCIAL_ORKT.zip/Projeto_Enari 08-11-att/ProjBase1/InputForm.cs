﻿using System;
using System.Windows.Forms;

namespace ProjBase1
{
    public partial class InputForm : Form
    {
        public string Valor { get; private set; }

        public InputForm(string mensagem)
        {
            InitializeComponent();
            labelMensagem.Text = mensagem;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void buttonOK_Click_1(object sender, EventArgs e)
        {
            Valor = textBoxInput.Text;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void buttonCancelar_Click_1(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void labelMensagem_Click(object sender, EventArgs e)
        {

        }
    }
}
